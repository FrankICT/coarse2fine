import sqlCon
import numpy as np



class processor:
    def __init__(self,cate):
        self.cate = cate
        self.entLis = {}
        self.entCnt = 0
        self.preCntDic = {}
        self.preCntDicUnfiltered = {}
        self.preInfoEntroDic = {}
        self.preInfoEntroRatioDic= {}
        self.sp = sqlCon.sqlProcesser()
        self.preValueDic = {}
        self.preCntLisDV = []
        self.preCntDicDV = {}
        self.pre_totalCnt_dic = {}

    def build_pre_totalCnt_dic(self):
        pre_lis = []
        self.entLis = self.sp.select_ins_given_cate_2level(self.cate)
        for sub in self.entLis:
            sub_preLis = list(set(self.sp.select_pre_given_sub(sub)))
            pre_lis += sub_preLis
        pre_lis = list(set(pre_lis))
        for pre in pre_lis:
            cnt = self.sp.select_pre_cnt_in_dbpedia(pre)
            self.pre_totalCnt_dic[pre] = cnt
        self.preTotalCntLis = sorted(self.pre_totalCnt_dic.iteritems(),key = lambda pair:pair[1],reverse=True)
        print 'pre_totalCnt_dic built'


    def build_pre_cnt_dic(self):
        self.entLis = self.sp.select_ins_given_cate_2level(self.cate)
        for sub in self.entLis:
            preLis = list(set(self.sp.select_pre_given_sub(sub)))
            if len(preLis) != 0:
                self.entCnt += 1
            for pre in preLis:
                if self.preCntDicUnfiltered.has_key(pre):
                    self.preCntDicUnfiltered[pre] += 1
                else:
                    self.preCntDicUnfiltered[pre] = 1
        self.filter(0)
        self.preCntLis = sorted(self.preCntDic.iteritems(),key = lambda pair:pair[1],reverse=True)
        for pair in self.preCntLis:
            pre = pair[0]
            cnt = pair[1]
            valueDic = self.get_value_dic(pre)
            self.preCntLisDV.append([pre,cnt/float(len(valueDic))])
            self.preCntDicDV[pre] = cnt/float(len(valueDic))
        self.preCntLisDV = sorted(self.preCntDicDV.iteritems(),key = lambda pair:pair[1],reverse=True)
        print "pre_cnt_dic built"

    def build_pre_info_dic(self):
        for pre in self.preCntDic.keys():
            infoEntro,infoEntroRatio = self.cal_info_entro(pre)
            self.preInfoEntroDic[pre] = infoEntro
            self.preInfoEntroRatioDic[pre] = infoEntroRatio
        self.preInfoEntroLis = sorted(self.preInfoEntroDic.iteritems(),key = lambda pair:pair[1],reverse=True)
        self.preInfoEntroRatioLis = sorted(self.preInfoEntroRatioDic.iteritems(),key = lambda pair:pair[1],reverse=True)
        print "pre_info_dic built"

    def filter(self,f = 1):
        self.preCntDic = self.preCntDicUnfiltered

    def get_value_dic(self,pre):
        subLis = "("
        for i in range(len(self.entLis)-1):
            ent = self.entLis[i]
            ent = ent.replace("'","''")
            subLis += "'" + ent + "',"
        subLis += "'" + self.entLis[-1] + "')"
        return self.sp.select_obj_given_pre_and_subLis(pre,subLis)

    def cal_info_entro(self,pre):
        valueDic = self.get_value_dic(pre)
        total = float(self.entCnt)
        info_entro = 0
        # if len(valueDic) <= 1:
        #     return 0,0
        for value in valueDic.keys():
            p = valueDic[value]/total
            info_entro += (-1) * p * np.log2(p)
        info_entro_ratio = info_entro/float(len(valueDic))
        return info_entro,info_entro_ratio

    def after_prc(self):
        minCnt = self.entCnt/20.0
        self.displayLis = []
        for pair in self.preInfoEntroRatioLis:
            pre = pair[0]
            if self.preCntDic[pre] < minCnt:
                continue
            self.displayLis.append(pre)
        self.infoEntroLis = []
        for pair in self.preInfoEntroLis:
            pre = pair[0]
            if self.preCntDic[pre] < minCnt:
                continue
            self.infoEntroLis.append(pre)
        self.cntLis = []
        for pair in self.preCntLis:
            pre = pair[0]
            if self.preCntDic[pre] < minCnt:
                continue
            self.cntLis.append(pre)
        self.cntLisDV = []
        for pair in self.preCntLisDV:
            pre = pair[0]
            if self.preCntDic[pre] < minCnt:
                continue
            self.cntLisDV.append(pre)



    def display(self):
        cnt = 1
        print "# of entity : " + str(self.entCnt)
        print "cate name : " + self.cate
        print '\n'
        for pre in self.displayLis:
            print str(cnt) +" : " + pre
            print "preCnt : " + str(self.preCntDic[pre]/float(self.entCnt))
            print "preInfoEntro : " + str(self.preInfoEntroDic[pre])
            print "preInfoEntroRatio : " + str(self.preInfoEntroRatioDic[pre])
            print '\n'
            cnt += 1

    def write(self):
        # write file according to preInfoEntroRatio
        f = open("exp_rec/" + self.cate + "(er).txt",'w')
        f.write("cate name : " + self.cate + '\n')
        f.write("# of entity : " + str(self.entCnt) + '\n\n')
        cnt = 1
        for pre in self.displayLis:
            f.write(str(cnt) +" : " + pre + '\n')
            f.write("preCnt : " + str(self.preCntDic[pre]/float(self.entCnt)) + '\n')
            f.write("preInfoEntro : " + str(self.preInfoEntroDic[pre]) + '\n')
            f.write("preInfoEntroRatio : " + str(self.preInfoEntroRatioDic[pre]) + '\n')
            f.write('\n')
            cnt += 1
        f.close()
        # write file according to preInfoEntro
        f = open("exp_rec/" + self.cate + "(e).txt",'w')
        f.write("cate name : " + self.cate + '\n')
        f.write("# of entity : " + str(self.entCnt) + '\n\n')
        cnt = 1
        for pre in self.infoEntroLis:
            f.write(str(cnt) +" : " + pre + '\n')
            f.write("preCnt : " + str(self.preCntDic[pre]/float(self.entCnt)) + '\n')
            f.write("preInfoEntro : " + str(self.preInfoEntroDic[pre]) + '\n')
            f.write("preInfoEntroRatio : " + str(self.preInfoEntroRatioDic[pre]) + '\n')
            f.write('\n')
            cnt += 1
        f.close()
        # write file according to preCnt
        f = open("exp_rec/" + self.cate + "(cnt).txt",'w')
        f.write("cate name : " + self.cate + '\n')
        f.write("# of entity : " + str(self.entCnt) + '\n\n')
        cnt = 1
        for pre in self.cntLis:
            f.write(str(cnt) +" : " + pre + '\n')
            f.write("preCnt : " + str(self.preCntDic[pre]/float(self.entCnt)) + '\n')
            f.write("preInfoEntro : " + str(self.preInfoEntroDic[pre]) + '\n')
            f.write("preInfoEntroRatio : " + str(self.preInfoEntroRatioDic[pre]) + '\n')
            f.write('\n')
            cnt += 1
        f.close()
        # write file according to preCntDV
        f = open("exp_rec/" + self.cate + "(cntDV).txt",'w')
        f.write("cate name : " + self.cate + '\n')
        f.write("# of entity : " + str(self.entCnt) + '\n\n')
        cnt = 1
        for pre in self.cntLisDV:
            f.write(str(cnt) +" : " + pre + '\n')
            f.write("preCntDV : " + str(self.preCntDicDV[pre]/float(self.entCnt)) + '\n')
            f.write("preCnt : " + str(self.preCntDic[pre]/float(self.entCnt)) + '\n')
            f.write("preInfoEntro : " + str(self.preInfoEntroDic[pre]) + '\n')
            f.write("preInfoEntroRatio : " + str(self.preInfoEntroRatioDic[pre]) + '\n')
            f.write('\n')
            cnt += 1
        f.close()

    def write_baseline(self):
        f = open("exp_rec/" + self.cate + "(tcnt).txt",'w')
        f.write("cate name : " + self.cate + '\n')
        f.write("# of attributes : " + str(len(self.pre_totalCnt_dic)) + '\n\n')
        cnt = 1
        for pair in self.preTotalCntLis:
            pre = pair[0]
            totalCnt = pair[1]
            try:
                f.write(str(cnt) +" : " + pre + '\n')
                f.write("preTotalCnt : " + str(totalCnt) + '\n')
                f.write('\n')
            except:
                continue
            cnt += 1
        f.close()

    def a_main(self):
        self.build_pre_totalCnt_dic()
        self.write_baseline()

    def display_raw(self):
        cnt = 1
        print "cate name : " + self.cate
        print "# of entity : " + str(self.entCnt)
        print '\n'
        for pair in self.preInfoEntroRatioLis:
            pre = pair[0]
            print str(cnt) +" : " + pre
            print "preCntPercentage : " + str(self.preCntDic[pre]/float(self.entCnt))
            print "preInfoEntro : " + str(self.preInfoEntroDic[pre])
            print "preInfoEntroRatio : " + str(self.preInfoEntroRatioDic[pre])
            print '\n'
            cnt += 1

    def main(self):
        print "\n"
        self.build_pre_cnt_dic()
        self.build_pre_info_dic()
        self.after_prc()
        self.display()
        self.write()

class grader:
    def __init__(self):
        self.f_in = open("f_in.txt",'r')
        self.cateLis = []
        for line in self.f_in:
            if len(line) < 3 :
                continue
            line = line.replace('(soso)','')
            line = line.replace(' ','')
            self.cateLis.append(line)
        self.z5 = 0.0
        self.z3 = 0.0
        for i in range(1,6):
            self.z5 += 7/np.log2(1+i)
        for i in range(1,4):
            self.z3 += 7/np.log2(1+i)
        self.avgScore_cnt_lis = []
        self.avgScore_cntDV_lis = []
        self.avgScore_e_lis = []
        self.avgScore_er_lis = []
        self.avgScore_tcnt_lis = []
        self.ndcg5_cnt_lis = []
        self.ndcg5_cntDV_lis = []
        self.ndcg5_e_lis = []
        self.ndcg5_er_lis = []
        self.ndcg5_tcnt_lis = []
        self.ndcg3_cnt_lis = []
        self.ndcg3_cntDV_lis = []
        self.ndcg3_e_lis = []
        self.ndcg3_er_lis = []
        self.ndcg3_tcnt_lis = []

    def new(self):
        self.f_in = open("f_in.txt",'r')
        self.cateLis = []
        for line in self.f_in:
            if len(line) < 3 :
                continue
            line = line.replace('(soso)','')
            line = line.replace(' ','')
            line = line.replace('\n','')
            self.cateLis.append(line)
        for cate in self.cateLis:
            print "processing : " + cate
            prc = processor(cate)
            prc.a_main()



    def gen_proc(self):
        cnt = 0
        avgScore_cnt = 0
        avgScore_cntDV = 0
        avgScore_e = 0
        avgScore_er = 0
        avgScore_tcnt = 0
        ndcg5_cnt = 0
        ndcg5_cntDV = 0
        ndcg5_e = 0
        ndcg5_er = 0
        ndcg5_tcnt = 0
        ndcg3_cnt = 0
        ndcg3_cntDV = 0
        ndcg3_e = 0
        ndcg3_er = 0
        ndcg3_tcnt = 0
        for name in self.cateLis:
            cnt += 1
            name = name.replace("\n","")
            name1 = "exp_rec/" + name + "(cnt).txt"
            name2 = "exp_rec/" + name + "(e).txt"
            name3 = "exp_rec/" + name + "(er).txt"
            name4 = "exp_rec/" + name + "(cntDV).txt"
            name5 = "exp_rec/" + name + "(tcnt).txt"
            avgScore1,ndcg5_1,ndcg3_1 = self.calculate(name1)
            avgScore2,ndcg5_2,ndcg3_2 = self.calculate(name2)
            avgScore3,ndcg5_3,ndcg3_3 = self.calculate(name3)
            avgScore4,ndcg5_4,ndcg3_4 = self.calculate(name4)
            avgScore5,ndcg5_5,ndcg3_5 = self.calculate(name5)
            avgScore_cnt += avgScore1
            avgScore_cntDV += avgScore4
            avgScore_e += avgScore2
            avgScore_er += avgScore3
            avgScore_tcnt += avgScore5
            ndcg5_cnt += ndcg5_1
            ndcg5_cntDV += ndcg5_4
            ndcg5_e += ndcg5_2
            ndcg5_er += ndcg5_3
            ndcg5_tcnt += ndcg5_5
            ndcg3_cnt += ndcg3_1
            ndcg3_cntDV += ndcg3_4
            ndcg3_e += ndcg3_2
            ndcg3_er += ndcg3_3
            ndcg3_tcnt += ndcg3_5
            self.avgScore_cnt_lis.append(avgScore1)
            self.avgScore_cntDV_lis.append(avgScore4)
            self.avgScore_e_lis.append(avgScore2)
            self.avgScore_er_lis.append(avgScore3)
            self.avgScore_tcnt_lis.append(avgScore5)
            self.ndcg5_cnt_lis.append(ndcg5_1)
            self.ndcg5_cntDV_lis.append(ndcg5_4)
            self.ndcg5_e_lis.append(ndcg5_2)
            self.ndcg5_er_lis.append(ndcg5_3)
            self.ndcg5_tcnt_lis.append(ndcg5_5)
            self.ndcg3_cnt_lis.append(ndcg3_1)
            self.ndcg3_cntDV_lis.append(ndcg3_4)
            self.ndcg3_e_lis.append(ndcg3_2)
            self.ndcg3_er_lis.append(ndcg3_3)
            self.ndcg3_tcnt_lis.append(ndcg3_5)
            
        print "avgScore_cnt : " + str(avgScore_cnt/float(cnt))
        print "avgScore_cntDV : " + str(avgScore_cntDV/float(cnt))
        print "avgScore_e : " + str(avgScore_e/float(cnt))
        print "avgScore_er : " + str(avgScore_er/float(cnt))
        print "avgScore_tcnt : " + str(avgScore_tcnt/float(cnt))
        print ''
        print "ndcg5_cnt : " + str(ndcg5_cnt/float(cnt))
        print "ndcg5_cntDV : " + str(ndcg5_cntDV/float(cnt))
        print "ndcg5_e : " + str(ndcg5_e/float(cnt))
        print "ndcg5_er : " + str(ndcg5_er/float(cnt))
        print "ndcg5_tcnt : " + str(ndcg5_tcnt/float(cnt))
        print ''
        print "ndcg3_cnt : " + str(ndcg3_cnt/float(cnt))
        print "ndcg3_cntDV : " + str(ndcg3_cntDV/float(cnt))
        print "ndcg3_e : " + str(ndcg3_e/float(cnt))
        print "ndcg3_er : " + str(ndcg3_er/float(cnt))
        print "ndcg3_tcnt : " + str(ndcg3_tcnt/float(cnt))

    def calculate(self,name):
        f = open(name)
        scoreLis = []
        for line in f:
            if line.startswith('6 : <http://dbpedia'):
                break
            if len(line) < 3 and line != '\n':
                scoreLis.append(int(line))
        scoreLisx = scoreLis[:3]
        avgScore = 0
        # wMap = 0
        ndcg5 = 0
        ndcg3 = 0
        cnt1 = 0.0
        cnt2 = 0.0
        for item in scoreLis:
            cnt1 += 1.0
            avgScore += item
            if item != 0:
                # wMap += item * v_cnt / cnt
                ndcg5 += (2 ** (item) - 1) / np.log2(1 + cnt1)
        for item in scoreLisx:
            cnt2 += 1.0
            if item != 0:
                ndcg3 += (2 ** (item) - 1) / np.log2(1 + cnt2)

        try:
            avgScore /= 5.0
            # wMap /= v_cnt
            ndcg5 /= self.z5
            ndcg3 /= self.z3
            return avgScore,ndcg5,ndcg3
        except:
            print name
        # print "avgScore : " + str(avgScore)
        # print "wMap : " + str(wMap)

    def t_test(self):
        # test AvgScore
        n = len(self.avgScore_er_lis)
        xa_1 = np.mean(self.avgScore_cnt_lis)
        xa_2 = np.mean(self.avgScore_e_lis)
        xa_3 = np.mean(self.avgScore_er_lis)
        xa_4 = np.mean(self.avgScore_cntDV_lis)
        va_1 = np.var(self.avgScore_cnt_lis)
        va_2 = np.var(self.avgScore_e_lis)
        va_3 = np.var(self.avgScore_er_lis)
        va_4 = np.var(self.avgScore_cntDV_lis)
        vca_13 = ((n - 1) * va_1 + (n - 1) * va_3) / float(2 * (n - 1))
        vca_23 = ((n - 1) * va_2 + (n - 1) * va_3) / float(2 * (n - 1))
        vca_43 = ((n - 1) * va_4 + (n - 1) * va_4) / float(2 * (n - 1))
        sa_13 = np.sqrt(vca_13 * (2*n)/(n*n))
        sa_23 = np.sqrt(vca_23 * (2*n)/(n*n))
        sa_43 = np.sqrt(vca_43 * (2*n)/(n*n))
        ta_13 = (xa_3 - xa_1)/sa_13
        ta_23 = (xa_3 - xa_2)/sa_23
        ta_43 = (xa_3 - xa_4)/sa_43
        freedom_degree = 2*n-2
        print "n : " + str(freedom_degree)
        print "ta_13 : " + str(ta_13)
        print "ta_23 : " + str(ta_23)
        print "ta_43 : " + str(ta_43)
        print ''

        # test NDCG@5
        xn_1 = np.mean(self.ndcg5_cnt_lis)
        xn_2 = np.mean(self.ndcg5_e_lis)
        xn_3 = np.mean(self.ndcg5_er_lis)
        xn_4 = np.mean(self.ndcg5_cntDV_lis)
        vn_1 = np.var(self.ndcg5_cnt_lis)
        vn_2 = np.var(self.ndcg5_e_lis)
        vn_3 = np.var(self.ndcg5_er_lis)
        vn_4 = np.var(self.ndcg5_cntDV_lis)
        vcn_13 = ((n - 1) * vn_1 + (n - 1) * vn_3) / float(2 * (n - 1))
        vcn_23 = ((n - 1) * vn_2 + (n - 1) * vn_3) / float(2 * (n - 1))
        vcn_43 = ((n - 1) * vn_4 + (n - 1) * vn_3) / float(2 * (n - 1))
        sn_13 = np.sqrt(vcn_13 * (2*n)/(n*n))
        sn_23 = np.sqrt(vcn_23 * (2*n)/(n*n))
        sn_43 = np.sqrt(vcn_43 * (2*n)/(n*n))
        tn_13 = (xn_3 - xn_1)/sn_13
        tn_23 = (xn_3 - xn_2)/sn_23
        tn_43 = (xn_3 - xn_4)/sn_43
        print "tn_13 : " + str(tn_13)
        print "tn_23 : " + str(tn_23)
        print "tn_43 : " + str(tn_43)
        print ''

        # test NDCG@3
        xm_1 = np.mean(self.ndcg3_cnt_lis)
        xm_2 = np.mean(self.ndcg3_e_lis)
        xm_3 = np.mean(self.ndcg3_er_lis)
        xm_4 = np.mean(self.ndcg3_cntDV_lis)
        vm_1 = np.var(self.ndcg3_cnt_lis)
        vm_2 = np.var(self.ndcg3_e_lis)
        vm_3 = np.var(self.ndcg3_er_lis)
        vm_4 = np.var(self.ndcg3_cntDV_lis)
        vcm_13 = ((n - 1) * vm_1 + (n - 1) * vm_3) / float(2 * (n - 1))
        vcm_23 = ((n - 1) * vm_2 + (n - 1) * vm_3) / float(2 * (n - 1))
        vcm_43 = ((n - 1) * vm_4 + (n - 1) * vm_3) / float(2 * (n - 1))
        sm_13 = np.sqrt(vcm_13 * (2*n)/(n*n))
        sm_23 = np.sqrt(vcm_23 * (2*n)/(n*n))
        sm_43 = np.sqrt(vcm_43 * (2*n)/(n*n))
        tm_13 = (xm_3 - xm_1)/sm_13
        tm_23 = (xm_3 - xm_2)/sm_23
        tm_43 = (xm_3 - xm_4)/sm_43
        print "tm_13 : " + str(tm_13)
        print "tm_23 : " + str(tm_23)
        print "tm_43 : " + str(tm_43)







