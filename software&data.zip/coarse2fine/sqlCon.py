# -*- coding: UTF-8 -*-

import pymysql
import sys

class sqlProcesser:
    def __init__(self,db = "new_dbpedia"):
        try:
            conn = pymysql.connect(host = 'localhost',user = 'root',charset='utf8', password = 'knowledge',port = 3306)
            conn.select_db(db)
            cur = conn.cursor()
        except:
            print "error : can't link to Database"
        self.conn = conn
        self.cur = cur
        self.path = "/Volumes/Store/work/"

    def insert_facts(self,sub,pre,obj):
        insSql = "insert into facts (sub,pre,obj) values (%s,%s,%s)"
        try:
            self.cur.execute(insSql,(sub,pre,obj))
            self.conn.commit()
        except:
            print "insert_facts error : " + sub + "\t" + pre + "\t" + obj

    def insert_cate(self,ins,cate):
        insSql = "insert into cate (ins,cate) values (%s,%s)"
        try:
            self.cur.execute(insSql,(ins,cate))
            self.conn.commit()
        except:
            print "insert_cate error : " + ins + '\t' + cate

    def insert_tax(self,sub,par):
        insSql = "insert into tax (sub,par) values (%s,%s)"
        try:
            self.cur.execute(insSql,(sub,par))
            self.conn.commit()
        except:
            print "insert_tax error : " + sub + '\t' + par

    def insert_cate_skos(self,sub,mom):
        insSql = "insert into cate_skos (sub,mom) values(%s,%s)"
        try:
            self.cur.execute(insSql,(sub,mom))
            self.conn.commit()
        except:
            print "insert_cate_skos error : " + sub + '\t' + mom

    def select_pre_cnt_in_dbpedia(self,pre):
        selSql = "SELECT count(*) FROM new_dbpedia.facts where pre = '" + pre + "';"
        try:
            self.cur.execute(selSql)
            res= self.cur.fetchall()
            return res[0][0]
        except:
            print "select_pre_cnt_in_dbpedia(self,pre) error : " + pre

    def select_ins_given_cate(self,cate):
        cate = cate.replace("'","''")
        selSql = "SELECT ins FROM new_dbpedia.cate where cate = '" + cate + "';"
        try:
            self.cur.execute(selSql)
            rawRes = self.cur.fetchall()
            res = []
            for item in rawRes:
                res.append(item[0])
            return res
        except:
             print "select_ins_given_cate error : " + cate

    def select_subcate_given_momcate(self,momcate):
        momcate = momcate.replace("'","''")
        selSql = "SELECT sub FROM new_dbpedia.cate_skos where mom = '" + momcate + "';"
        try:
            self.cur.execute(selSql)
            rawRes = self.cur.fetchall()
            res = []
            for item in rawRes:
                res.append(item[0])
            return res
        except:
             print "select_ins_given_cate error : " + momcate

    def select_ins_given_cate_2level(self,cate):
        cate = cate.replace("'","''")
        selSql = "SELECT ins FROM new_dbpedia.cate where cate = '" + cate + "';"
        res = []
        try:
            self.cur.execute(selSql)
            rawRes = self.cur.fetchall()
            for item in rawRes:
                res.append(item[0])
        except:
             print "select_ins_given_cate error 1 : " + cate
        subcateLis = self.select_subcate_given_momcate(cate)
        for subcate in subcateLis:
            subcate = subcate.replace("'","''")
            selSql = "SELECT ins FROM new_dbpedia.cate where cate = '" + subcate + "';"
            try:
                self.cur.execute(selSql)
                rawRes = self.cur.fetchall()
                for item in rawRes:
                    res.append(item[0])
            except:
                print "select_ins_given_cate error 2 : " + subcate
        return list(set(res))

    def select_pre_given_sub(self,sub):
        sub = sub.replace("'","''")
        selSql = "SELECT pre FROM new_dbpedia.facts where sub = '" + sub + "';"
        try:
            self.cur.execute(selSql)
            rawRes = self.cur.fetchall()
            res = []
            for item in rawRes:
                res.append(item[0])
            return res
        except:
            print "select_pre_given_sub error : " + sub

    def select_obj_given_pre_and_subLis(self,pre,subLis):
        selSql = "SELECT obj FROM new_dbpedia.facts where pre = '" + pre + "' and sub in " + subLis
        try:
            self.cur.execute(selSql)
            rawRes = self.cur.fetchall()
            res = []
            for item in rawRes:
                res.append(item[0])
            dic = {}
            for value in res:
                if dic.has_key(value):
                    dic[value] += 1
                else:
                    dic[value] = 1
            return dic
        except:
            print "select_obj_given_pre_and_subLis error : " + pre

    def select_distinct_pre(self):
        selSql = "SELECT distinct(pre) FROM new_dbpedia.facts"
        try:
            self.cur.execute(selSql)
            rawRes = self.cur.fetchall()
            res = []
            for item in rawRes:
                res.append(item[0])
            return res
        except:
            print "select_distinct_pre error"

    def insert_pre(self,pre):
        cnt = self.select_pre_cnt(pre)
        insSql = "insert into pre (pre,cnt) values (%s,%s)"
        try:
            self.cur.execute(insSql,(pre,cnt))
            self.conn.commit()
        except:
            print "insert_pre error : " + pre + '\t' + cnt

    def select_pre_cnt(self,pre):
        selSql = "select count(*) from facts where pre  = '" + pre + "'"
        try:
            self.cur.execute(selSql)
            rawRes = self.cur.fetchall()
            res = rawRes[0][0]
            return res
        except:
            print "select_pre_cnt error"

    def build_pre_lis(self):
        lis = self.select_distinct_pre()
        cnt = 0
        for pre in lis:
            self.insert_pre(pre)
            cnt += 1
            if cnt % 100 == 0:
                print "cnt : " + str(cnt)


