# build up a concept lattice for a given categoty
import re
import time
import sqlCon
import numpy as np
import txtPrc
import ml
import assis
from sklearn.cluster import AffinityPropagation

class anx:

    # abandon temporally
    def __init__(self,dic1 = {},dic10 = {},dic0Pid = {},pidList = {}):
        self.pidList = pidList
        self.dic1 = dic1
        self.dic10 = dic10
        self.dicAttrValue = dic10
        self.dic0Pid = self.valuePidDicFilter(dic0Pid,pidList)
        self.dic1Pid = {}
        self.dic10toDic1Pid()
        self.sp = sqlCon.sqlProcesser('wiki')
        self.clusterDicL1 = {}
        self.clusterDicL2 = {}
        self.clusterDicL3 = {}
        self.attrDicL1 = {}
        self.attrDicL2 = {}
        self.attrDicL3 = {}




    # def __init__(self,dic1 = {},dic2 = {},dic3 = {},\
    #              dic32 = {},dic21 = {},dic10 = {},\
    #              dic0Pid = {},pidList = {}):
    #     self.pidList = pidList
    #     self.dic1 = dic1
    #     self.dic2 = dic2
    #     self.dic3 = dic3
    #     self.dic32 = dic32
    #     self.dic21 = dic21
    #     self.dic10 = dic10
    #     self.dic20 = {}
    #     self.dic30 = {}
    #     # self.dic40 = {}
    #     self.dic0Pid = self.valuePidDicFilter(dic0Pid,pidList)
    #     # self.dic4Pid = {}
    #     self.dic3Pid = {}
    #     self.dic2Pid = {}
    #     self.dic1Pid = {}
    #     # self.dic43toDic4Pid()
    #     self.dic32toDic3Pid()
    #     self.dic21toDic2Pid()
    #     self.dic10toDic1Pid()
    #     self.dicAttrPid = self.dicCombination()
    #     self.dicAttrValue = self.dicCombination2()
    #     self.buildDicValueAttr()
    #     self.cidVecDic = {}
    #     self.pidVecDic = {}
    #     self.sp = sqlCon.sqlProcesser('wiki')




    def printNameGivenCidDicOrList(self,cidInput):
        sp = sqlCon.sqlProcesser('wiki')
        if type(cidInput) == dict:
            testKey = cidInput.values()[0]
            if type(testKey) == int:
                for cid in cidInput:
                    print sp.fetWikiCnameGivenCid(cid) + '  ' + str(cid) + '    ' + str(cidInput[cid])
            elif type(testKey) == list:
                for cid in cidInput:
                    print sp.fetWikiCnameGivenCid(cid) +'   ' + str(cid) + '    ' + str(len(cidInput[cid]))
            else:
                print 'printNameGivenCidDic error!'
        elif type(cidInput) == list:
            for cid in cidInput:
                print sp.fetWikiCnameGivenCid(cid)

    def printNameGivenPidList(self,pidList):
        sp = sqlCon.sqlProcesser('wiki')
        for pid in pidList:
            print sp.fetWikiPnameWithPid(pid)

    def queryDirectChild(self,cid):
        childCidList = []
        if cid in self.dic21.keys():
            childCidList += self.dic21[cid]
        if cid in self.dic32.keys():
            childCidList += self.dic32[cid]
        if cid in self.dic43.keys():
            childCidList += self.dic43[cid]
        childCidList = set(childCidList)
        childCidList = list(childCidList)
        return childCidList

    def queryDirectChildPcntVarience(self,cid):
        parentPcnt = float(len(self.dicAttrPid[cid]))
        childCidList = self.queryDirectChild(cid)
        if childCidList == []:
            return 0.0
        childPcntList = []
        for childCid in childCidList:
            childPcntList.append(len(self.dicAttrPid[childCid])/parentPcnt)
        childPcntArray = np.array(childPcntList)
        childPcntVar = np.var(childPcntArray)
        return childPcntVar

    def queryMotherCid(self,cid):
        potentialMomcidList = self.sp.fetWikiCateInlinks(cid)
        keys = self.dicAttrPid.keys()
        momCidList = []
        for cid in potentialMomcidList:
            if cid in keys:
                momCidList.append(cid)
        return momCidList

    def querySiblingCid(self,cid):
        siblingCidList = []
        momCidList = self.queryMotherCid(cid)
        for momCid in momCidList:
            if momCid in self.dic21:
                siblings = self.dic21[momCid]
                if cid in siblings:
                    siblingCidList.append(siblings)
            if momCid in self.dic32:
                siblings = self.dic32[momCid]
                if cid in siblings:
                    siblingCidList.append(siblings)
            if momCid in self.dic43:
                siblings = self.dic43[momCid]
                if cid in siblings:
                    siblingCidList.append(siblings)
        return siblingCidList

    def querySiblingPartitionality(self,cid):
        siblingCidList = self.querySiblingCid(cid)
        if siblingCidList == []:
            return 0,0
        elif len(siblingCidList) == 1:
            return 0,0
        else:
            for siblings in siblingCidList:
                pidCntList = []
                meanList = []
                varList = []
                for sibling in siblings:
                    pidCnt = len(self.dicAttrPid[sibling])
                    pidCntList.append(pidCnt)
                    pidCntArr = np.array(pidCntList)
                    mean = pidCntArr.mean()
                    var = pidCntArr.var()
                    meanList.append(int(mean))
                    varList.append(int(var))
                mean = max(meanList)
                var = varList[meanList.index(mean)]
                return mean,var

    def buildDicValueAttr(self):
        self.dicValueAttr = {}
        for attr in self.dicAttrValue.keys():
            for value in self.dicAttrValue[attr]:
                if self.dicValueAttr.has_key(value):
                    self.dicValueAttr[value].append(attr)
                else:
                    self.dicValueAttr[value] = [attr]

    # def calValueDistance(self,value1,value2):
    #     itxon = intersection
    #     dist = 0.0
    #     l1Set1 = set(self.sp.fetWikiCidlistWithPid(value1))
    #     l1Set2 = set(self.sp.fetWikiCidlistWithPid(value2))
    #     itxon1 = l1Set1.intersection(l1Set2)
    #     dist += len(itxon1)/(len(l1Set1.union(l1Set2))*1.0+1)
    #     # l1Set1 = l1Set1 - itxon1
    #     # l1Set2 = l1Set2 - itxon1
    #     l2Set1 = self.calValueDistanceFetMomCidList(l1Set1)
    #     l2Set2 = self.calValueDistanceFetMomCidList(l1Set2)
    #     itxon2 = l2Set1.intersection(l2Set2)
    #     dist += len(itxon2)/(len(l2Set1.union(l2Set2))*3.0+1)
    #     # l2Set1 = l2Set1 - itxon2
    #     # l2Set2 = l2Set2 - itxon2
    #     l3Set1 = self.calValueDistanceFetMomCidList(l2Set1)
    #     l3Set2 = self.calValueDistanceFetMomCidList(l2Set2)
    #     itxon3 = l3Set1.intersection(l3Set2)
    #     dist += len(itxon3)/(len(l3Set1.union(l3Set2))*10.0+1)
    #     return dist
    #
    #
    #
    # def calValueDistanceFetMomCidList(self,st):
    #     retList = []
    #     for cid in st:
    #         retList += self.sp.fetWikiMomCidlistWithCid(cid)
    #     return set(retList)

    #     def calValueDistanecePrep(self):
    #     self.dic1Keys = self.dic1.keys()
    #     self.dic2Keys = self.dic2.keys()
    #     self.dic3Keys = self.dic3.keys()
    #     self.dic4Keys = self.dic4.keys()







    def queryAttrLevel(self,attr):
        levelSum = 0
        levelNum = 0.0
        if attr in self.dic1.keys():
            levelSum += 1
            levelNum += 1
        if attr in self.dic2.keys():
            levelSum += 2
            levelNum += 1
        if attr in self.dic3.keys():
            levelSum += 3
            levelNum += 1
        if attr in self.dic4.keys():
            levelSum += 4
            levelNum += 1
        return levelSum/levelNum








    def dicConv(self,cidListUp,dicUpDown):
        retList = []
        for item in cidListUp:
            retList += dicUpDown[item]
        return retList

    def dic43toDic4Pid(self):
        dic42 = self.dic43.copy()
        for key in dic42.keys():
            cidList3 = dic42[key]
            dic42[key] = self.dicConv(cidList3,self.dic32)
        dic41 = dic42.copy()
        for key in dic41.keys():
            cidList2 = dic41[key]
            dic41[key] = self.dicConv(cidList2,self.dic21)
        dic40 = dic41.copy()
        for key in dic40.keys():
            cidList1 = dic40[key]
            dic40[key] = self.dicConv(cidList1,self.dic10)
        self.dic40 = dic40
        # filter
        for key in dic40.keys():
            dic40[key] = set(dic40[key])
            self.dic40[key] = list(dic40[key])
        # filter
        dic4Pid = dic40.copy()
        for key in dic4Pid.keys():
            cidList0 = dic4Pid[key]
            dic4Pid[key] = self.dicConv(cidList0,self.dic0Pid)
        # filter
        for key in dic4Pid.keys():
            dic4Pid[key] = set(dic4Pid[key])
            self.dic4Pid[key] = list(dic4Pid[key])
        # filter

    def dic32toDic3Pid(self):
        dic31 = self.dic32.copy()
        for key in dic31.keys():
            cidList2 = dic31[key]
            dic31[key] = self.dicConv(cidList2,self.dic21)
        dic30 = dic31.copy()
        for key in dic30.keys():
            cidList1 = dic30[key]
            dic30[key] = self.dicConv(cidList1,self.dic10)
        self.dic30 = dic30
        # filter
        for key in self.dic3Pid.keys():
            self.dic3Pid[key] = set(self.dic3Pid[key])
            self.dic3Pid[key] = list(self.dic3Pid[key])
        # filter
        dic3Pid = dic30.copy()
        for key in dic3Pid.keys():
            cidList0 = dic3Pid[key]
            dic3Pid[key] = self.dicConv(cidList0,self.dic0Pid)
        # filter
        for key in dic3Pid.keys():
            dic3Pid[key] = set(dic3Pid[key])
            self.dic3Pid[key] = list(dic3Pid[key])
        # filter

    def dic21toDic2Pid(self):
        dic20 = self.dic21.copy()
        for key in dic20.keys():
            cidList1 = dic20[key]
            dic20[key] = self.dicConv(cidList1,self.dic10)
        self.dic20 = dic20
        # filter
        for key in self.dic2Pid.keys():
            self.dic2Pid[key] = set(self.dic2Pid[key])
            self.dic2Pid[key] = list(self.dic2Pid[key])
        # filter
        dic2Pid = dic20.copy()
        for key in dic2Pid.keys():
            cidList0 = dic2Pid[key]
            dic2Pid[key] = self.dicConv(cidList0,self.dic0Pid)
        # filter
        for key in dic2Pid.keys():
            dic2Pid[key] = set(dic2Pid[key])
            self.dic2Pid[key] = list(dic2Pid[key])
        # filter

    def dic10toDic1Pid(self):
        dic1Pid = self.dic10.copy()
        for key in dic1Pid.keys():
            cidList0 = dic1Pid[key]
            dic1Pid[key] = self.dicConv(cidList0,self.dic0Pid)
        # filter
        for key in dic1Pid.keys():
            dic1Pid[key] = set(dic1Pid[key])
            self.dic1Pid[key] = list(dic1Pid[key])
        # filter

    def dicCombination(self):
        # dicList = [self.dic1Pid,self.dic2Pid,self.dic3Pid,self.dic4Pid]
        dicList = [self.dic1Pid,self.dic2Pid,self.dic3Pid]
        dicAttrPid = dicList[0].copy()
        for dic in dicList[1:]:
            for key in dic.keys():
                if dicAttrPid.has_key(key):
                    dicAttrPid[key] += dic[key]
                else:
                    dicAttrPid[key] = dic[key]
        for key in dicAttrPid:
            dicAttrPid[key] = set(dicAttrPid[key])
            dicAttrPid[key] = list(dicAttrPid[key])
        return dicAttrPid

    def dicCombination2(self):
        # dicList = [self.dic10,self.dic20,self.dic30,self.dic40]
        dicList = [self.dic10,self.dic20,self.dic30]
        dicAttrValue = dicList[0].copy()
        for dic in dicList[1:]:
            for key in dic.keys():
                if dicAttrValue.has_key(key):
                    dicAttrValue[key] += dic[key]
                else:
                    dicAttrValue[key] = dic[key]
        for key in dicAttrValue:
            dicAttrValue[key] = set(dicAttrValue[key])
            dicAttrValue[key] = list(dicAttrValue[key])
        return dicAttrValue

    # def dic0PidFilter(self,dic0Pid,pidList):
    def valuePidDicFilter(self,dic0Pid,pidList):
        for outLinkKey in dic0Pid.keys():
            pidValueList = dic0Pid[outLinkKey][:]
            exchangeSet = set([])
            for pidValue in pidValueList:
                if pidValue in pidList:
                    exchangeSet.add(pidValue)
            dic0Pid[outLinkKey] = list(exchangeSet)
        return dic0Pid

    def buildNameInLinkDic(self,pid):
        sp = sqlCon.sqlProcesser('wiki')
        outLinkList = sp.fetWikiPidOutLinkListGivenPid(pid)
        nameOutLinkDic = {}
        for outLink in outLinkList:
            name = sp.fetWikiPnameWithPid(outLink)
            nameOutLinkDic[name] = outLink
        return nameOutLinkDic

    def pidVecCombination(self,subPidList):
        cidVec = np.zeros(300)
        tWeight = 0
        for pid in subPidList:
            if not self.pidVecDic.has_key(pid):
                continue
            else:
                weight = len(self.sp.fetWikiPageContent(pid))/1000 + 1
                pidVec = self.pidVecDic[pid]
                cidVec += weight * pidVec
                tWeight += weight
        cidVec /= tWeight
        return cidVec

    def buildCidVecDic(self):
        print 'start building cidVecDic...'
        pidList = []
        for pidGroup in self.dicAttrValue.values():
            pidList += pidGroup
        pidList = set(pidList)
        pidList = list(pidList)
        vl = ml.vecLearner(pidList)
        vl.learn()
        print 'generating cidVecDic...'
        self.pidVecDic = vl.pidVecDic
        for cid in self.dicAttrValue.keys():
            subPidList = self.dicAttrValue[cid]
            cidVec = self.pidVecCombination(subPidList)
            self.cidVecDic[cid] = cidVec
        print 'cidVecDic build complete!'




    def buildValueAdjMat(self):
        start = time.clock()
        print 'start building adjacency matrix...'
        valueList = []
        # valueList = self.dic0Pid.keys()
        for subValueList in self.dic10.values():
            valueList += subValueList
        valueList = list(set(valueList))
        self.valueList = valueList
        mat = np.zeros((len(valueList),len(valueList)))
        for i in range(len(valueList)):
            if i % 100 == 0:
                t = time.clock()
                print str(100*i/float(len(valueList))) + '% complete,   time consumed : ' + str(t-start)
            for j in range(i,len(valueList)):
                if i > j:
                    mat[i,j] = mat[j,i]
                elif i == j:
                    mat[i,j] = 0.0
                else:
                    mat[i,j] = self.calValueDistance(valueList[i],valueList[j])
        end = time.clock()
        print 'time consumed : ' + str(end - start)
        self.mat = mat

    def calValueDistance(self,value1,value2):
        attrSet1 = set(self.dicValueAttr[value1])
        attrSet2 = set(self.dicValueAttr[value2])
        attrItxon = attrSet1.intersection(attrSet2)
        attrUnion = attrSet1.union(attrSet2)
        grade = 0.0
        for item in attrItxon:
            grade += 1/float(self.abstractDic[item])
        return grade/float(len(attrUnion))

    ################# old version #################
    # def attrCluster(self):
    #     print 'start clustering, please wait...'
    #     if len(self.mat) == 0:
    #         print 'error : no value adjacency matrix'
    #         return
    #     start = time.clock()
    #     clusterDic = {}
    #     af = AffinityPropagation(affinity='precomputed',preference=0.0)
    #     prediction = af.fit_predict(self.mat)
    #     for i in range(len(prediction)):
    #         pred = prediction[i]
    #         value = self.valueList[i]
    #         if clusterDic.has_key(pred):
    #             clusterDic[pred].append(value)
    #         else:
    #             clusterDic[pred] = [value]
    #     self.clusterDic = clusterDic
    #     end = time.clock()
    #     print 'clustering complete, time consumed : ' + str(end - start)
    #
    #
    #
    # def attrRanking(self,clusterId):
    #     attrList = []
    #     attrGradeList = []
    #     valueList = self.clusterDic[clusterId]
    #     for value in valueList:
    #         attrList += self.dicValueAttr[value]
    #     attrList = list(set(attrList))
    #     for attr in attrList:
    #         grade = self.attrGrading(attr,clusterId)
    #         attrGradeList.append([grade,attr])
    #     attrGradeList.sort(reverse=True)
    #     return attrGradeList
    #
    # def attrGrading(self,attr,clusterId):
    #     grade = 0
    #     attrValuelist = self.dicAttrValue[attr]
    #     # importtance & relevance
    #     for value in self.clusterDic[clusterId]:
    #         if value in attrValuelist:
    #             doc = self.sp.fetWikiPageContent(value)
    #             grade += np.log((len(doc)/10000.0) + 1)
    #     # abstract
    #     # grade /= self.queryAttrLevel(attr) failed
    #     grade /= self.queryAttrLevel(attr)
    #     return grade
    #
    # def clusterGrading(self,clusterId):
    #     valueList = self.clusterDic[clusterId]
    #     subPidList = []
    #     for value in valueList:
    #         subPidList += self.dic0Pid[value]
    #     relevance = len(subPidList)/float(len(self.pidList))
    #     importance = 0.0
    #     for pid in subPidList:
    #         importance += np.log((len(self.sp.fetWikiPageContent(pid))/10000.0) + 1)
    #     importance /= float(len(subPidList)+1)
    #     return importance*relevance

    # def top20top5(self):
    #     clusterList = []
    #     for clusterId in self.clusterDic.keys():
    #         clusterList.append([self.clusterGrading(clusterId),clusterId])
    #     clusterList.sort(reverse=True)
    #     clusterList = clusterList[:20]
    #     i = 0
    #     for item in clusterList:
    #         i += 1
    #         clusterId = item[1]
    #         print 'top' + str(i) + ' cluster'
    #         print 'values : ',
    #         for pid in self.clusterDic[item[1]]:
    #             print self.sp.fetWikiPnameWithPid(pid) + ' ; ',
    #         print ''
    #         j = 1
    #         attrList = self.attrRanking(clusterId)[:5]
    #         for attr in attrList:
    #             print ' attr' + str(j) + ' ' + str(self.sp.fetWikiCnameGivenCid(attr[1]))
    #             j += 1
    ################# old version #################




    def calCateDis(self,cate1,cate2):
        alpha = 2
        beta = 2
        gamma = 1
        delta = 3.5
        epsilion = 10
        momCate1 = self.momCateDic[cate1]
        subCate1 = self.subCateDic[cate1]
        ent1 = self.entDic[cate1]
        name1 = set(assis.cNamePrc(self.sp.fetWikiCnameGivenCid(cate1)))
        value1 = set(self.dic10[cate1])
        momCate2 = self.momCateDic[cate2]
        subCate2 = self.subCateDic[cate2]
        ent2 = self.entDic[cate2]
        name2 = set(assis.cNamePrc(self.sp.fetWikiCnameGivenCid(cate2)))
        value2 = set(self.dic10[cate2])
        return alpha * (len(momCate1.intersection(momCate2))/(1 + 1.0*len(momCate1.union(momCate2))))\
                    + beta * (len(subCate1.intersection(subCate2))/(1 + 1.0*len(subCate1.union(subCate2))))\
                    + gamma * (len(ent1.intersection(ent2))/(1 + 1.0*len(ent1.union(ent2))))\
                    + delta * (len(name1.intersection(name2))/(1 + 1.0*len(name1.union(name2))))\
                    + epsilion * (len(value1.intersection(value2))/(1 + 1.0*len(value1.union(value2))))



    ############################    start from 315     ############################

    def buildCateDisMatOld(self):
        s = time.clock()
        # step1 build a matrix that contains all momCates / subCates / entities
        print 'building category distance matrix. start initialization, please wait...'
        self.cateList = self.dicAttrValue.keys()
        self.momCateDic = {}
        self.subCateDic = {}
        self.entDic = {}
        for cate in self.cateList:
            self.momCateDic[cate] = set(self.sp.wikiCateFilter(self.sp.fetWikiMomCidGivenCid(cate)))
            self.subCateDic[cate] = set(self.sp.wikiCateFilter(self.sp.fetWikiSubcategoryIndex(cate)))
            self.entDic[cate] = set(self.sp.fetWikiPidlistGivenCid(cate))
        alpha = 2
        beta = 2
        gamma = 1
        delta = 5   # 3.5
        epsilion = 25   # 18
        # step2 build cateDis matrix
        mat = np.zeros((len(self.cateList),len(self.cateList)))
        for i in range(len(self.cateList)):
            if i % 50 == 0:
                c = time.clock()
                print str(i/(0.01 * len(self.cateList))) + '% complete, time consumed : ' + str(c-s)
            cidi = self.cateList[i]
            momCate1 = self.momCateDic[cidi]
            subCate1 = self.subCateDic[cidi]
            ent1 = self.entDic[cidi]
            name1 = set(assis.cNamePrc(self.sp.fetWikiCnameGivenCid(cidi)))
            value1 = set(self.dic10[cidi])
            for j in range(len(self.cateList)):
                if j < i:
                    mat[i,j] = mat[j,i]
                elif i == j:
                    mat[i,j] = 0
                elif j > i:
                    cidj = self.cateList[j]
                    momCate2 = self.momCateDic[cidj]
                    subCate2 = self.subCateDic[cidj]
                    ent2 = self.entDic[cidj]
                    name2 = set(assis.cNamePrc(self.sp.fetWikiCnameGivenCid(cidj)))
                    value2 = set(self.dic10[cidj])
                    mat[i,j] = alpha * (len(momCate1.intersection(momCate2))/(1 + 1.0*len(momCate1.union(momCate2))))\
                    + beta * (len(subCate1.intersection(subCate2))/(1 + 1.0*len(subCate1.union(subCate2))))\
                    + gamma * (len(ent1.intersection(ent2))/(1 + 1.0*len(ent1.union(ent2))))\
                    + delta * (len(name1.intersection(name2))/(1 + 1.0*len(name1.union(name2))))\
                    + epsilion * (len(value1.intersection(value2))/(1 + 1.0*len(value1.union(value2))))
        self.cateDisMat = mat
        print 'category distance matrix built'

    # def buildCateDisMatOld(self):
    #     s = time.clock()
    #     # step1 build a matrix that contains all momCates / subCates / entities
    #     print 'building category distance matrix. start initialization, please wait...'
    #     self.cateList = self.dicAttrValue.keys()
    #     momCateDic = {}
    #     subCateDic = {}
    #     entDic = {}
    #     for cate in self.cateList:
    #         momCateDic[cate] = set(self.sp.wikiCateFilter(self.sp.fetWikiMomCidGivenCid(cate)))
    #         subCateDic[cate] = set(self.sp.wikiCateFilter(self.sp.fetWikiSubcategoryIndex(cate)))
    #         entDic[cate] = set(self.sp.fetWikiPidlistGivenCid(cate))
    #     alpha = 2
    #     beta = 2
    #     gamma = 1
    #     # step2 build cateDis matrix
    #     mat = np.zeros((len(self.cateList),len(self.cateList)))
    #     for i in range(len(self.cateList)):
    #         if i % 50 == 0:
    #             c = time.clock()
    #             print str(i/(0.01 * len(self.cateList))) + '% complete, time consumed : ' + str(c-s)
    #         momCate1 = momCateDic[self.cateList[i]]
    #         subCate1 = subCateDic[self.cateList[i]]
    #         ent1 = entDic[self.cateList[i]]
    #         for j in range(len(self.cateList)):
    #             if j < i:
    #                 mat[i,j] = mat[j,i]
    #             elif i == j:
    #                 mat[i,j] = 0
    #             elif j > i:
    #                 momCate2 = momCateDic[self.cateList[j]]
    #                 subCate2 = subCateDic[self.cateList[j]]
    #                 ent2 = entDic[self.cateList[j]]
    #                 mat[i,j] = alpha * (len(momCate1.intersection(momCate2))/(1 + 1.0*len(momCate1.union(momCate2))))\
    #                 + beta * (len(subCate1.intersection(subCate2))/(1 + 1.0*len(subCate1.union(subCate2))))\
    #                 + gamma * (len(ent1.intersection(ent2))/(1 + 1.0*len(ent1.union(ent2))))
    #     self.cateDisMat = mat
    #     print 'category distance matrix built'

    def buildCateDisMat(self):
        cv = assis.cate2Vec(self.dicAttrValue)
        self.cateDisMat = cv.main()

    def attrCluster(self,preference = 0.0):
        print 'start clustering, please wait...'
        if len(self.cateDisMat) == 0:
            print 'error : no value adjacency matrix'
            return
        start = time.clock()
        clusterDic = {}
        af = AffinityPropagation(affinity='precomputed',preference=preference)
        prediction = af.fit_predict(self.cateDisMat)
        for i in range(len(prediction)):
            pred = prediction[i]
            cate = self.cateList[i]
            if clusterDic.has_key(pred):
                clusterDic[pred].append(cate)
            else:
                clusterDic[pred] = [cate]
        self.clusterDicL1 = clusterDic
        self.siluatGradeDic = assis.siluatClusterGrade(self.cateDisMat,prediction)
        end = time.clock()
        print 'clustering complete, time consumed : ' + str(end - start)

####################### all these functions below serve for buildDicAttrValue() #######################
    def attrGeneration(self,inputDic = {},cutNum = 2):
        if inputDic == {}:
            inputDic = self.clusterDicL1
        retDic = {}
        for key in inputDic.keys():
            subAttrList = inputDic[key]
            momAttrDic = {}
            for subAttr in subAttrList:
                momAttrList = self.sp.fetWikiMomCidGivenCid(subAttr)
                for momAttr in momAttrList:
                    if momAttrDic.has_key(momAttr):
                        momAttrDic[momAttr].add(subAttr)
                    else:
                        momAttrDic[momAttr] = set([subAttr])

            for momAttr in momAttrDic.keys():
                if len(momAttrDic[momAttr]) <  cutNum:
                    momAttrDic.pop(momAttr)
            momAttrDic = self.sp.wikiCateFilter4Dic(momAttrDic)
            retDic[key] = momAttrDic
        return retDic

    def dicL3toDicL1(self):
        self.clusterDicL3toLow = {}
        for key in self.clusterDicL3.keys():
            dicL3toL1GivenKey = self.dicL3toDicL1PidGivenKey(key)
            self.clusterDicL3toLow[key] = dicL3toL1GivenKey

    def dicL3toDicL1PidGivenKey(self,key):
        dicL3 = self.clusterDicL3[key]
        dicL2 = self.clusterDicL2[key]
        dicL3toL1 = {}
        for attrL3 in dicL3.keys():
            dicL3toL1[attrL3] = []
            attrL2List = dicL3[attrL3]
            for attrL2 in attrL2List:
                attrL1List = dicL2[attrL2]
                dicL3toL1[attrL3] += attrL1List
            dicL3toL1[attrL3] = list(set(dicL3toL1[attrL3]))
        return dicL3toL1

    def dicAttr2ValueLow(self):
        dicAttr2Value = {}
        for key in self.clusterDicL1.keys():
            dicAttr2ValueGivenKey = {}
            for attr in self.clusterDicL1[key]:
                dicAttr2ValueGivenKey[attr] = self.dic10[attr]
            dicAttr2Value[key] = dicAttr2ValueGivenKey
        return dicAttr2Value

    def dicAttr2ValueHigh(self,inputDic):
        dicAttr2Value = {}
        for key in inputDic.keys():
            dicAttr2ValueGivenKey = {}
            for attr in inputDic[key].keys():
                subAttrList = inputDic[key][attr]
                valueList = []
                for subAttr in subAttrList:
                    valueList += self.dic10[subAttr]
                if dicAttr2ValueGivenKey.has_key(attr):
                    dicAttr2ValueGivenKey[attr] += valueList
                else:
                    dicAttr2ValueGivenKey[attr] = valueList
                dicAttr2ValueGivenKey[attr] = list(set(dicAttr2ValueGivenKey[attr]))
            dicAttr2Value[key] = dicAttr2ValueGivenKey
        return dicAttr2Value

    def buildClusterValueDic(self):
        clusterValueDic = {}
        for key in self.clusterDicL1.keys():
            clusterValueDic[key] = []
            attrL1List = self.clusterDicL1[key]
            for attr in attrL1List:
                clusterValueDic[key] += self.dic10[attr]
            clusterValueDic[key] = list(set(clusterValueDic[key]))
        self.clusterValueDic = clusterValueDic

####################### all these functions above serve for buildDicAttrValue() #######################
    def buildDicAttrValue(self):
        print 'building attribute value dictionary, please wait...'
        self.attrCluster(-0.5)   # the original value is -1.0 for cid = 12398791    Touchscreen_mobile_phones
        self.clusterDicL2 = self.attrGeneration(self.clusterDicL1)
        self.clusterDicL3 = self.attrGeneration(self.clusterDicL2)
        self.dicL3toDicL1()
        self.buildClusterValueDic()
        self.clusterDicL1toValue = self.dicAttr2ValueLow()
        self.clusterDicL2toValue = self.dicAttr2ValueHigh(self.clusterDicL2)
        self.clusterDicL3toValue = self.dicAttr2ValueHigh(self.clusterDicL3toLow)
        print 'attribute value dictionary built.'






############################################# start from 4.28 #############################################







































