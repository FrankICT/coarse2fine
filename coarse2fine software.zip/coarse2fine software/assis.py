
from sklearn.metrics import silhouette_samples
import numpy as np
import sqlCon
import time
from sklearn.feature_extraction.text import CountVectorizer
import re



def siluatClusterGrade(cateDisMat,prediction):
    sampleValue = silhouette_samples(X=cateDisMat,labels=prediction)
    gradeDic = {}
    retDic = {}
    for i in range(len(prediction)):
        clusterId = prediction[i]
        if gradeDic.has_key(clusterId):
            gradeDic[clusterId].append(sampleValue[i])
        else:
            gradeDic[clusterId] = [sampleValue[i]]
    for key in gradeDic.keys():
        retDic[key] = np.mean(gradeDic[key]) + 1
    return retDic



def logisticFunc(t,x=3):
    return 2/(1.0 + np.power(x,-1.0*t)) -1




def hits2(self,key):
        alpha = 0.5
        attr0 = self.attrWeightListDic[key][:]
        attrOld = np.zeros(len(attr0))
        attrN = attr0
        value0 = self.valueWeightListDic[key][:]
        valueN = value0
        matL = self.matLDic[key].copy()
        matTL = self.matTLDic[key].copy()
        iterCnt = 0
        while self.vecDifference(attrOld,attrN) > 0.01:
            iterCnt += 1
            attrOld = attrN
            attrN = alpha * attr0 + (1-alpha) * self.vecNormalize(np.dot(matL,valueN))
            valueN = alpha * value0 + (1-alpha) * self.vecNormalize(np.dot(matTL,attrN))
        # print 'iteration time : ' + str(iterCnt)
        return attrN    # valueN



class cate2Vec:
    def __init__(self,dicAttrValue):
        self.dicAttrValue = dicAttrValue
        self.wordList = []
        self.momCateList = []
        self.subCateList = []
        self.entList = []
        self.sp = sqlCon.sqlProcesser()
        self.cidVecDic = {}



    # return momVecDic / subVecDic / entVecDic
    def wiki2Vec(self):
        print 'wiki2Vecing, please wait...'
        momCorpus = []
        subCorpus = []
        # entCorpus = []
        vectorizer = CountVectorizer(min_df=1)
        for cid in self.dicAttrValue.keys():
            momCidList = self.sp.fetWikiMomCidGivenCid(cid)
            subCidList = self.sp.fetWikiSubcategoryIndex(cid)
            # entList = self.sp.fetWikiPidlistGivenCid(cid)
            momStr = ''
            subStr = ''
            # entStr = ''
            for momCid in momCidList:
                momStr += str(momCid) + ' '
            for subCid in subCidList:
                subStr += str(subCid) + ' '
            # for ent in entList:
            #     entStr += str(ent) + ' '
            momCorpus.append(momStr)
            subCorpus.append(subStr)
            # entCorpus.append(entStr)
        self.momVecList = vectorizer.fit_transform(momCorpus)
        self.subVecList = vectorizer.fit_transform(subCorpus)
        # self.entVecList = vectorizer.fit_transform(entCorpus)
        # load vectors into a dic
        self.momVecDic = {}
        self.subVecDic = {}
        # self.entVecDic = {}
        cateList = self.dicAttrValue.keys()
        for i in range(len(cateList)):
            cateId = cateList[i]
            momVec = self.momVecList[i]
            subVec = self.subVecList[i]
            # entVec = self.entVecList[i]
            self.momVecDic[cateId] = momVec.toarray()[0]
            self.subVecDic[cateId] = subVec.toarray()[0]
            # self.entVecDic[cateId] = entVec.toarray()[0]
        print 'wiki2Vec completed!'



    # return valueVecDic
    def value2Vec(self):
        print 'value2Vecing, please wait...'
        valueCorpus = []
        vectorizer = CountVectorizer(min_df=1)
        for cid in self.dicAttrValue.keys():
            valueList = self.dicAttrValue[cid]
            valueStr = ''
            for value in valueList:
                valueStr += str(value) + ' '
            valueCorpus.append(valueStr)
        self.valueVecList = vectorizer.fit_transform(valueCorpus)
        self.valueVecDic = {}
        cateList = self.dicAttrValue.keys()
        for i in range(len(cateList)):
            cateId = cateList[i]
            valueVec = self.valueVecList[i]
            self.valueVecDic[cateId] = valueVec.toarray()[0]
        print 'value2Vec completed!'



    # return nameVecDic
    def name2Vec(self):
        print 'name2Vecing, please wait...'
        nameCorpus = []
        vectorizer = CountVectorizer(min_df=1)
        for cid in self.dicAttrValue.keys():
            cname = self.sp.fetWikiCnameGivenCid(cid).replace('_',' ').lower()
            # print cname               # for debug use
            pat = re.compile('[^a-z,A-Z, ]')
            se = pat.search(cname)
            if se != None:
                cname = cname[:se.start()] + cname[se.endpos:]
            nameCorpus.append(cname)
        self.nameVecList = vectorizer.fit_transform(nameCorpus)
        self.nameVecDic = {}
        cateList = self.dicAttrValue.keys()
        for i in range(len(cateList)):
            cateId = cateList[i]
            nameVec = self.nameVecList[i]
            self.nameVecDic[cateId] = nameVec.toarray()[0]
        print 'name2Vec completed!'



    def buildCateDisMat(self,dic):
        cateList = dic.keys()
        mat = np.array([[0.0 for col in range(len(cateList))] for row in range(len(cateList))])
        for i in range(len(cateList)):
            cid1 = cateList[i]
            vec1 = dic[cid1]
            for j in range(len(cateList)):
                if i > j:
                    mat[i][j] = mat[j][i]
                elif i == j:
                    mat[i][j] = 0
                else:
                    cid2 = cateList[j]
                    vec2 = dic[cid2]
                    dis = np.dot(vec1,vec2)/float(np.sum(vec1+vec2)+1)
                    mat[i][j] = dis
        return mat



    def main(self):
        print 'start building cateDisMat, it\'s going to take a looong time......'
        t0 = time.clock()
        self.wiki2Vec()
        self.momDisMat = self.buildCateDisMat(self.momVecDic)
        self.subDisMat = self.buildCateDisMat(self.subVecDic)
        # self.entDisMat = self.buildCateDisMat(self.entVecDic)
        t1 = time.clock()
        print 'wiki2Vec time consumed : ' + str(t1-t0)
        self.value2Vec()
        self.valueDisMat = self.buildCateDisMat(self.valueVecDic)
        t2 = time.clock()
        print 'value2Vec time consumed : ' + str(t2-t1)
        self.name2Vec()
        self.nameDisMat = self.buildCateDisMat(self.nameVecDic)
        t3 = time.clock()
        print 'name2Vec time consumed : ' + str(t3-t2)
        self.cateDisMat = 0.1 * self.nameDisMat +  0.1 * self.valueDisMat + 0.4 * self.momDisMat + 0.2 * self.subDisMat
        return self.cateDisMat



    def inspect(self,cid1,cid2):
        vec1 = self.nameVecDic[cid1]
        vec2  =self.nameVecDic[cid2]
        nameSim = np.dot(vec1,vec2)/(np.sum(vec1+vec2)+0.1)
        print 'name sim :   ' + str(nameSim)
        vec3 = self.valueVecDic[cid1]
        vec4  =self.valueVecDic[cid2]
        valueSim = np.dot(vec3,vec4)/(np.sum(vec3+vec4)+0.1)
        print 'value sim :  ' + str(valueSim)
        vec5 = self.momVecDic[cid1]
        vec6  =self.momVecDic[cid2]
        momSim = np.dot(vec5,vec6)/(np.sum(vec5+vec6)+0.1)
        print 'mom sim :    ' + str(momSim)
        vec7 = self.subVecDic[cid1]
        vec8  =self.subVecDic[cid2]
        subSim = np.dot(vec7,vec8)/(np.sum(vec7+vec8)+0.1)
        print 'sub sim :    ' + str(subSim)
        print 'final score: ' + str(0.3 * nameSim + 0.3 * valueSim + 0.2 * momSim + 0.2 * subSim)



def cNamePrc(cName):
    try:
        retName = cName.lower()
        byPos1 = retName.find('_by_')
        if byPos1 != -1:
            retName = retName[:byPos1]
        byPos2 = retName.find('_of_')
        if byPos2 != -1:
            retName = retName[:byPos2]
        pat1 = re.compile('_[^_]+_[i,o]n_')
        se = pat1.search(retName)
        if se != None:
            retName = retName[:se.start()]
        return retName.split('_')
    except:
        print 'cNamePrc error : ' + str(cName)
        return 'error'



def cNameCmp(cName1,cName2):
    cName1Real = cName1[-1]
    cName2Real = cName2[-1]
    if cName1Real == cName2Real:
        return 1
    else:
        return 0











