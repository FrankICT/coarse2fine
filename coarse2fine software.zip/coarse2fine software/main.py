import sqlCon
import annex
import bgr
import assis
import time



def main():
    cid = 12398791  # Touchscreen_mobile_phones    only 346 entities less noise,less computation time
    sp = sqlCon.sqlProcesser()

    pidList = sp.fetWikiPidlistGivenCid2Level(cid)
    # sp.attrRanking5(pidList)
    # pidList = sp.fetWikiPidlistGivenCid(cid)
    # pidList = sp.fetWikiPidlistGivenCidRecur(cid)
    dic1,dic10,dic0Pid = sp.fetWikiPotentialAttrGivenCid1level(cid)
    anx = annex.anx(dic1,dic10,dic0Pid,pidList)
    anx.buildCateDisMatOld()

    bg = bgr.bg(anx,cid)
    bg.buildDicAttrValue()
    bg.writeRes()

if __name__ == '__main__':
    print 'here we go!'
    sp = sqlCon.sqlProcesser()
    cid0 = sp.fetWikiCidWithCname('Cooking_techniques')
    cid1 = sp.fetWikiCidWithCname('Pistols')
    cid2 = sp.fetWikiCidWithCname('Operas')
    cid3 = sp.fetWikiCidWithCname('Military_helicopters')
    cidList1 = [cid1,cid2,cid3,cid0]
    for cid in cidList1:
        pidList = sp.fetWikiPidlistGivenCid(cid)
        dic1,dic10,dic0Pid = sp.fetWikiPotentialAttrGivenCid1level(cid)
        anx = annex.anx(dic1,dic10,dic0Pid,pidList)
        anx.buildCateDisMatOld()

        bg = bgr.bg(anx,cid)
        bg.buildDicAttrValue()
        bg.writeRes()

    cidList2 = []
    cidx = sp.fetWikiCidWithCname('Wine_by_country')
    cidy = sp.fetWikiCidWithCname('Coffee_beverages')
    cidList2 = [cidx,cidy]
    for cid in cidList2:
        pidList = sp.fetWikiPidlistGivenCid2Level(cid)
        dic1,dic10,dic0Pid = sp.fetWikiPotentialAttrGivenCid1level(cid)
        anx = annex.anx(dic1,dic10,dic0Pid,pidList)
        anx.buildCateDisMatOld()

        bg = bgr.bg(anx,cid)
        bg.buildDicAttrValue()
        bg.writeRes()

        cid = sp.fetWikiCidWithCname('Artists_by_period')
        pidList = sp.fetWikiPidlistGivenCid2Level(cid)
        # pidList = sp.fetWikiPidlistGivenCid(cid)
        for line in sp.attrRanking5(pidList):
            print line,

            sp.fetWikiPidlistGivenCidRecur()











