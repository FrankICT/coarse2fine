import sqlCon
import numpy as np
import re
from sklearn.cross_validation import KFold
from sklearn.svm import SVC
from sklearn.linear_model import SGDClassifier
from sklearn import tree
import random
from sklearn.cluster import AffinityPropagation



def qumo(vec):
    sum = 0.0
    newVec = []
    for item in vec:
        sum += np.power(item,2)
    sum = np.sqrt(sum)
    for item in vec:
        item = item / sum
        newVec.append(item)
    return np.array(newVec)

class sim:
    def __init__(self,dic):
        self.dic = dic


    def simScore(self,cid1,cid2):
        sp = sqlCon.sqlProcesser('wiki')
        vec1 = qumo(self.dic[cid1])
        vec2 = qumo(self.dic[cid2])
        name1 = sp.fetWikiCnameGivenCid(cid1)
        name2 = sp.fetWikiCnameGivenCid(cid2)
        print 'similarity between ' + name1 + '     ' + name2
        print str(np.dot(vec1,vec2))







import sqlCon
import annex
import txtPrc
import threading
import time




def buildNameList(cid):
    # cid = 953043
    retList = []
    sp = sqlCon.sqlProcesser()
    pidList = sp.fetWikiPidlistGivenCid2Level(cid)
    for pid in pidList:
        pidCon = sp.fetWikiPageContent(pid)
        prc = txtPrc.paraPrc(pidCon)
        nameList = prc.extractEntity()
        retList += nameList
    retList = list(set(retList))
    return retList

def buildNameDic(cid):
    # cid = 953043
    retDic = {}
    sp = sqlCon.sqlProcesser()
    pidList = sp.fetWikiPidlistGivenCid2Level(cid)
    for pid in pidList:
        pidCon = sp.fetWikiPageContent(pid)
        prc = txtPrc.paraPrc(pidCon)
        nameList = prc.extractEntity()
        for name in nameList:
            if retDic.has_key(name):
                retDic[name].append(pid)
            else:
                retDic[name] = [pid]
    return retDic

def buildNamePidDic(nameList):
    sp = sqlCon.sqlProcesser()
    totalLen = float(len(nameList))
    cnt = 0
    for nameStr in nameList:
        cnt += 1
        sp.insertWikiNamePidDic(nameStr)
        print nameStr
        if cnt %100 == 0:
            percent = cnt/totalLen
            print str(100 * percent) + '% complete.'
    print 'work complete'
#
# if  __name__ == '__main__':
#     cid = 953043
#     list = buildNameList(cid)
#     buildNamePidDic(list)

class fetPidGivemPname(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.thread_stop = False

    def run(self):
        cid = 953043
        self.thread_stop = False
        while not self.thread_stop:
            list = buildNameList(cid)
            buildNamePidDic(list)

    def stop(self):
        self.thread_stop = True

# def main():
#     thread1 = fetPidGivemPname()
#     thread1.start()
#     for i in range(100):
#         print 'start over!'
#         thread1.thread_stop = False
#         time.sleep(300)
#         thread1.stop()
#         continue

def main():
    cid = 953043
    sp = sqlCon.sqlProcesser()
    pidList = sp.fetWikiPidlistGivenCidRecur(cid)
    totalLength = len(pidList)
    i = 0
    for pid in pidList:

        print pid
        pidCon = sp.fetWikiPageContent(pid)
        prc = txtPrc.paraPrc(pidCon)
        nameList = prc.extractEntity()
        for name in nameList:
            relPid = sp.fetWikiPidFromNamePidDic(name)
            if relPid == None:
                print ' ' + name
                sp.insertWikiNamePidDic(name)
        i+=1
        if i%100 == 0:
            print '\n' + str(100*i/float(len(pidList))) + '% compeleted!\n'

def caca(con,trainL,testL):
    trainX = []
    testX = []
    trainy = []
    testy = []
    pat = re.compile('\[.+\]')
    for i in range(len(con)):
        line = con[i]
        y = int(line[-2])
        lis = pat.findall(line)[0][1:-1].split(',')
        for j in range(len(lis)):
            lis[j] = float(lis[j])
        X = lis
        if i in trainL:
            trainX.append(X)
            trainy.append(y)
        else:
            testX.append(X)
            testy.append(y)

    return trainX,trainy,testX,testy

def test(prediction,testy):
    tp = 0
    fp = 0
    tn = 0
    for i in range(len(prediction)):
        py = prediction[i]
        ty = testy[i]
        if py == 1 and ty == 1:
            tp += 1
        elif py == 1 and ty == 0:
            fp += 1
        elif py == 0 and ty == 1:
            tn += 1
    precision = tp/float(tp + fp)
    print 'precision : ' + str(precision)
    recall = tp/float(tp + tn)
    print 'recall : ' + str(recall)
    f = 2*precision*recall/(precision + recall)
    print 'f-measure : ' + str(f)

def cvSVM(X,y):
    kf = KFold(len(X), n_folds=3)
    cnt = 0
    for trainId,testId in kf:
        print 'test' + str(cnt)+':'
        cnt+=1
        trainX = []
        testX = []
        trainy = []
        testy = []
        for id1 in trainId:
            trainX.append(X[id1])
            trainy.append(y[id1])
        for id2 in testId:
            testX.append(X[id2])
            testy.append(y[id2])
        clf = SVC(kernel='linear')
        clf.fit(trainX,trainy)
        prediction = clf.predict(testX)
        test(prediction,testy)
    print 'cross validation over'

def cvSGD(X,y):
    kf = KFold(len(X),n_folds=4)
    cnt = 0
    for trainId,testId in kf:
        print 'test' + str(cnt)+':'
        cnt+=1
        trainX = []
        testX = []
        trainy = []
        testy = []
        for id1 in trainId:
            trainX.append(X[id1])
            trainy.append(y[id1])
        for id2 in testId:
            testX.append(X[id2])
            testy.append(y[id2])
        clf = SGDClassifier(loss="hinge", penalty="l2")
        clf.fit(trainX,trainy)
        prediction = clf.predict(testX)
        test(prediction,testy)
    print 'cross validation over'

def cvTree(X,y):
    kf = KFold(261, n_folds=3)
    cnt = 0
    for trainId,testId in kf:
        print 'test' + str(cnt)+':'
        cnt+=1
        trainX = []
        testX = []
        trainy = []
        testy = []
        for id1 in trainId:
            trainX.append(X[id1])
            trainy.append(y[id1])
        for id2 in testId:
            testX.append(X[id2])
            testy.append(y[id2])
        clf = tree.DecisionTreeClassifier()
        clf.fit(trainX,trainy)
        prediction = clf.predict(testX)
        test(prediction,testy)
    print 'cross validation over'

def cvGuess(X,y):
    kf = KFold(len(X),n_folds=4)
    cnt = 0
    for trainId,testId in kf:
        print 'test' + str(cnt)+':'
        cnt+=1
        trainX = []
        testX = []
        trainy = []
        testy = []
        for id1 in trainId:
            trainX.append(X[id1])
            trainy.append(y[id1])
        for id2 in testId:
            testX.append(X[id2])
            testy.append(y[id2])

        prediction = []
        for item in testy:
            prediction.append(random.randint(0,1))
        test(prediction,testy)
    print 'cross validation over'






class test314():
    def __init__(self,prediction):
        self.prediction = prediction
        self.sp = sqlCon.sqlProcesser()


def attrCluster(anx):
        print 'start clustering, please wait...'
        if len(anx.mat) == 0:
            print 'error : no value adjacency matrix'
            return
        start = time.clock()
        clusterDic = {}
        af = AffinityPropagation(affinity='precomputed',preference = -2.1)
        prediction = af.fit_predict(anx.mat)
        for i in range(len(prediction)):
            pred = prediction[i]
            value = anx.valueList[i]
            if clusterDic.has_key(pred):
                clusterDic[pred].append(value)
            else:
                clusterDic[pred] = [value]
        end = time.clock()
        print 'clustering complete, time consumed : ' + str(end - start)
        return clusterDic

def top10top5(self):
    clusterList = []
    for clusterId in self.clusterDic.keys():
        clusterList.append([self.clusterGrading(clusterId),clusterId])
    clusterList.sort(reverse=True)
    clusterList = clusterList[:10]
    i = 0
    for item in clusterList:
        i += 1
        clusterId = item[1]
        print 'top' + str(i) + ' cluster'
        j = 1
        attrList = self.attrRanking(clusterId)[:5]
        for attr in attrList:
            print ' attr' + str(j) + ' ' + str(self.sp.fetWikiCnameGivenCid(attr[1]))
            j += 1


def calAbstractLevel(cidList):
    start = time.clock()
    sp = sqlCon.sqlProcesser()
    file = open('cidPidNum.txt','w')
    writeList = []
    for i in range(len(cidList)):
        if i % 60 == 0:
            nowTime = time.clock()
            print str(i/(0.01 * len(cidList))) + '% completed.',
            print 'time consumed : ' + str(nowTime - start)
        cid = cidList[i]
        subPidList = sp.fetWikiPidlistGivenCidRecur(cid)
        subPidCnt = len(subPidList)
        line = str(cid) + ' : ' + str(subPidCnt + subPidCnt) + '\n'
        writeList.append(line)
    file.writelines(writeList)
    file.close()
    print 'calAbstractLevel over'

def readAbstractLevel():
    file = open('cidPidNum.txt','r')
    dic = {}
    numListRaw = file.readlines()
    for line in numListRaw:
        items = line.split(' : ')
        dic[int(items[0])] = np.power(int(items[1]),0.5)
    return dic

def dic2Lis(dic):
    retLis = []
    for key in dic:
        retLis.append([dic[key],key])
    return retLis

def showDic(dic):
    sp = sqlCon.sqlProcesser()
    for attr in dic.keys():
        print sp.fetWikiCnameGivenCid(attr) + ':\n   ',
        for value in dic[attr]:
            print sp.fetWikiPnameWithPid(value) + '; ',
        print ''

















