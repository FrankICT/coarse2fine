import sqlCon



sp1 = sqlCon.sqlProcesser('wiki')
sp2 = sqlCon.sqlProcesser('new_extraction')
class cateTreeNode:
    def __init__(self,cid):
        self.cid = cid
        self.cName = sp1.fetWikiCategoryName(cid)
        self.parent = None
        self.children = []

class cateTree:
    def __init__(self,cid):
        self.root = cateTreeNode(cid)
        self.nodeDic = {}
        self.nodeDic[cid] = self.root

    def addChild(self,parentCid,childCid):
        if parentCid not in self.nodeDic.keys():
            print "parentCid not in tree , add node failed"
            return
        parentNode = self.nodeDic[parentCid]
        childNode = cateTreeNode(childCid)
        childNode.parent = parentNode
        parentNode.children.append(childNode)
        self.nodeDic[childCid] = childNode

    def orderJudge(self,cid1,cid2,q):
        try:
            node1 = self.nodeDic[cid1]
            node2 = self.nodeDic[cid2]
        except:
            print 'given category not recorded , cid : ' + str(cid1) + ' ' + str(cid2)
            return 0
        try:
            node  = self.nodeDic[sp2.fetCid(q)]
        except:
            print 'given query not recorded , q : ' + str(q)
            return 0
        cnt = 1
        cid1Pos = -1
        cid2Pos = -1
        while 1:
            if cid1 == node.cid:
                cid1Pos = cnt
            elif cid2 == node.cid:
                cid2Pos = cnt
            if node.parent == None:
                break
            node = node.parent
            cnt += 1
        if cid1Pos > 0 and cid2Pos > 0:
            if cid1Pos < cid2Pos:
                return 1
            else:
                return 2
        elif cid1Pos > 0 and cid2Pos < 0:
            return 1
        elif cid1Pos < 0 and cid2Pos > 0:
            return 2
        elif cid1Pos < 0 and cid2Pos < 0:
            return 0
        else:
            return 0












        
