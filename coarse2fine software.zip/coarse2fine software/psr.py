import re



def psr1(inputStr):
    pat = re.compile('{{[^{}]+}}')
    strList = pat.findall(inputStr)
    for str in strList:
        alterStr = str[2:-2]
        alterStr = alterStr[alterStr.find('|')+1:]
        alterStr = alterStr.replace('*',',')
        alterStr = alterStr.replace('|',',')
        inputStr = inputStr.replace(str,alterStr)
    return inputStr


