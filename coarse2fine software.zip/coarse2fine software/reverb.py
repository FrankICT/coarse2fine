import re
import sqlCon
import time
import nltk
from nltk.stem.wordnet import WordNetLemmatizer

lmtzr = WordNetLemmatizer()

class reverb:
    def __init__(self,para,pName = '',cName = '',pid = 0,cid = 0):
        self.rawStr = para.replace('|',' ')   #   preprocess
        self.posStr = ''
        self.vStr = ''
        self.vpStr = ''
        self.npStr = ''
        self.extraction = []
        self.pid = pid
        self.cid = cid
        self.pName = pName
        self.cName = cName
        self.spx = sqlCon.sqlProcesser('new_extraction')
        # print "rawStr : " + self.rawStr

    def postag(self):
        if self.rawStr == '':
            print 'error'
            return
        strToken = nltk.word_tokenize(self.rawStr)
        listPos = nltk.pos_tag(strToken)
        retStr = ''
        for item in listPos:
            wordLemma = item[0]
            wordPos = item[1]
            retStr += '<' + wordPos + '>' + wordLemma + '</' + wordPos + '> '
        self.posStr = retStr
        # print("posStr : " + self.posStr)

    def postagFilter(self,input):
        pat = re.compile('<[^<>]+>')
        output = re.sub(pat,'',input)
        return output

    def vChunking(self):
        if self.posStr == '':
            print 'error'
            return
        vStr = self.posStr
        vPat = re.compile("((<VB[A-Z]?>[^<>]*</VB[A-Z]?>)( <RB>[^<>]*</RB>)?(( <RP>[^<>]*</RP>)|( <TO>[^<>]*</TO>))?)")
        changeList1 = vPat.findall(vStr)
        for changeItem in changeList1:
            replaceStr = '<V>' + self.postagFilter(changeItem[0]) + '</V>'
            vStr = re.sub(changeItem[0],replaceStr,vStr,1)
        pPat = re.compile("((<IN>[^<>]{0,100}</IN>)|(<RP>[^<>]{0,100}</RP>))")
        changeList2 = pPat.findall(vStr)
        for changeItem in changeList2:
            replaceStr = '<P>' + self.postagFilter(changeItem[0]) + '</P>'
            vStr = re.sub(changeItem[0],replaceStr,vStr,1)
        self.vStr = vStr
        # print("vStr : " + self.vStr)

    def vpChunking(self):
        if self.vStr == '':
            print 'error'
            return
        vpStr = self.vStr
        vpPat1 = re.compile("(<V>[^<>]*</V>(( <NN[A-Z]{0,2}>[^<>]{0,100}</NN[A-Z]{0,2}>)|( <JJ[A-Z]?>[^<>]{0,100}</JJ[A-Z]?>)|( <RB[A-Z]?>[^<>]{0,100}</RB[A-Z]?>)|( <PRP>[^<>]{0,100}</PRP>)|( <DT>[^<>]{0,100}</DT>))+( <P>[^<>]{0,100}</P>))")
        vpPat2 = re.compile("(<V>[^<>]*</V>( <P>[^<>]{0,100}</P>)?)")
        vpPat3 = re.compile("((<VP>[^<>]*</VP>)( <VP>[^<>]*</VP>)+)")
        changeList1 = vpPat1.findall(vpStr)
        for changeItem in changeList1:
            replaceStr = '<VP>' + self.postagFilter(changeItem[0]) + '</VP>'
            vpStr = re.sub(changeItem[0],replaceStr,vpStr,1)
        changeList2 = vpPat2.findall(vpStr)
        for changeItem in changeList2:
            replaceStr = '<VP>' + self.postagFilter(changeItem[0]) + '</VP>'
            vpStr = re.sub(changeItem[0],replaceStr,vpStr,1)
        changeList3 = vpPat3.findall(vpStr)
        for changeItem in changeList3:
            replaceStr = '<VP>' + self.postagFilter(changeItem[0]) + '</VP>'
            vpStr = re.sub(changeItem[0],replaceStr,vpStr,1)
        self.vpStr = vpStr
        # print("vpStr : " + self.vpStr)

    def npChunking(self):
        if self.vpStr == '':
            print 'error'
            return
        npStr = self.vpStr
        npPat1 = re.compile("(((<DT>[^<>]*</DT> )|(<PRP\\$?>[^<>]*</PRP\\$?> ))?(<JJ>[^<>]*</JJ> )*<NN>[^<>]*</NN> )")
        npPat2 = re.compile("((<NN[A-Z]{1,2}>[^<>]*</NN[A-Z]{1,2}> )+|(<NN>[^<>]*</NN{1,2}> ){2,})")
        npPat3 = re.compile("((<NP>[^<>]*</NP> ){2,})")
        # npPat4 = re.compile("((<PRP\\$?>[^<>]*</PRP\\$?> ))")
        changeList1 = npPat1.findall(npStr)
        for changeItem in changeList1:
            replaceStr = '<NP>' + self.postagFilter(changeItem[0]) + '</NP> '
            if replaceStr.endswith(' </NP> '):
                replaceStr = replaceStr.replace(' </NP>','</NP>')
            npStr = re.sub(changeItem[0],replaceStr,npStr,1)
        changeList2 = npPat2.findall(npStr)
        for changeItem in changeList2:
            replaceStr = '<NP>' + self.postagFilter(changeItem[0]) + '</NP> '
            if replaceStr.endswith(' </NP> '):
                replaceStr = replaceStr.replace(' </NP>','</NP>')
            npStr = re.sub(changeItem[0],replaceStr,npStr,1)
        changeList3 = npPat3.findall(npStr)
        for changeItem in changeList3:
            replaceStr = '<NP>' + self.postagFilter(changeItem[0]) + '</NP> '
            if replaceStr.endswith(' </NP> '):
                replaceStr = replaceStr.replace(' </NP>','</NP>')
            npStr = re.sub(changeItem[0],replaceStr,npStr,1)
        # changeList4 = npPat4.findall(npStr)
        # for changeItem in changeList4:
        #     replaceStr = '<NP>' + self.postagFilter(changeItem[0]) + '</NP> '
        #     if replaceStr.endswith(' </NP> '):
        #         replaceStr = replaceStr.replace(' </NP>','</NP>')
        #     npStr = re.sub(changeItem[0],replaceStr,npStr,1)
        self.npStr = npStr
        # print "npStr : " + self.npStr

    def extract(self):
        if self.npStr == '':
            print 'error'
            return
        extractStr = self.npStr
        sub = ''
        pre = ''
        obj = ''
        wordPat = re.compile("<([^<>]{0,4})>([^<>]*)</[^<>]{0,4}>")
        wordList = wordPat.findall(extractStr)
        for item in wordList:
            pos = item[0]
            word = item[1]
            if word == ',' or word == '.' or word == ';':
                sub = ''
                pre = ''
                obj = ''
            elif pre == '' and pos == 'NP':
                sub = self.wordFilter(word)
            elif sub != '' and pre == '' and pos == 'VP':
                pre = self.wordFilter(word)
            elif sub != '' and pre != '' and pos == 'NP':
                obj = self.wordFilter(word)
                lmSub = self.lemmatizer(sub,'n')
                lmPre = self.lemmatizer(pre,'v')
                lmObj = self.lemmatizer(obj,'n')
                extractionOutput = sub + '-->' + pre + '<--' + obj
                lmExtractionOutput = lmSub + '-->' + lmPre + '<--' + lmObj
                if lmSub in self.pName or lmSub == 'he' or lmSub == 'she':
                    lmSub = self.pName
                if lmObj in self.pName or lmObj == 'he' or lmObj == 'she':
                    lmObj = self.pName
                # print 'lemma form : ' + lmExtractionOutput + '   raw form : ' + extractionOutput

                # stroe reverb 2 DB
                self.extraction.append([lmSub,lmPre,lmObj])
                sub = ''
                pre = ''
                obj = ''

    def storeExtraction(self):
        for oneExtraction in self.extraction:
            sub = oneExtraction[0]
            pre = oneExtraction[1]
            obj = oneExtraction[2]
            self.spx.storeTriple2DB(self.pid,self.cid,self.pName,self.cName,sub,pre,obj)

    def storeSubPreObj(self):
        for oneExtraction in self.extraction:
            sub = oneExtraction[0]
            pre = oneExtraction[1]
            obj = oneExtraction[2]
            self.spx.storeReverbDic2DB(sub,'entity')
            self.spx.storeReverbDic2DB(obj,'entity')
            self.spx.storeReverbDic2DB(pre,'predicate')

    def lemmatizer(self,phrase,pos):
        words = phrase.split(' ')
        retStr = ''
        for word in words:
            try:
                word = lmtzr.lemmatize(word,pos)
            except:
                print "wordnet lemmatizer error, can't convert word : " + word
                return "ERROR WORD"
            retStr += word + ' '
        return retStr[:len(retStr) - 1]

    def wordFilter(self,wordStr):
        wordStr = wordStr.lower()
        pat = re.compile("[^a-z -']")
        errWordList = pat.findall(wordStr)
        if len(errWordList) != 0:
            print 'error word : ' + wordStr
        for item in errWordList:
            wordStr = re.sub(item,'',wordStr,1)
        return wordStr



class reverbExtraction:
    def __init__(self,cid,pid):
        self.cid = cid
        self.pid = pid
        self.spWiki = sqlCon.sqlProcesser('wiki')
        self.spE = sqlCon.sqlProcesser('new_extraction')
        self.cName = self.spWiki.fetWikiCategoryName(cid)
        self.pName = self.spWiki.fetWikiPageName(pid)
        self.doc = self.spWiki.fetWikiPageContent(pid)

    def rvbProecss(self,para):
        rvb = reverb(para,self.pName,self.cName,self.pid,self.cid)
        rvb.postag()
        rvb.vChunking()
        rvb.vpChunking()
        rvb.npChunking()
        rvb.extract()
        rvb.storeExtraction()
        print '\n'

    def extract(self):
        self.paraList= self.spE.docFilter(self.doc)
        for para in self.paraList:
            if len(para) < 50:
                continue
            try:
                self.rvbProecss(para)
            except:
                print 'doc reverb error'
                continue

class reverbCategory:
    def __init__(self,cid):
        self.cid = cid
        self.sp = sqlCon.sqlProcesser('wiki')

    def fetWikiCidPidSetRecur(self):
        for pid in self.sp.fetchWikiPageIndex(self.cid):
            rvbE = reverbExtraction(self.cid,pid)
            rvbE.extract()
        subCidList = self.sp.fetWikiSubcategoryIndexRecur(self.cid)
        for cid in subCidList:
            print 'processing cid : ' + str(cid)
            newPidList = self.sp.fetchWikiPageIndex(cid)
            for pid in newPidList:
                print ' processing pid : '+ str(pid)
                rvbE = reverbExtraction(self.cid,pid)
                rvbE.extract()






def rvbProcess(para,pName,cName,pid,cid):
    rvb = reverb(para,pName,cName,pid,cid)
    rvb.postag()
    rvb.vChunking()
    rvb.vpChunking()
    rvb.npChunking()
    rvb.extract()
    rvb.storeExtraction()
    print '\n'



def docReverb(sp,doc,pName,cName,pid,cid):
    paraList = sp.docFilter(doc)
    for para in paraList:
        if len(para) < 50:
            continue
        try:
            rvbProcess(para,pName,cName,pid,cid)
        except:
            print 'doc reverb error'
            continue



def reverbDicConstruction():
    start = time.clock()
    sp = sqlCon.sqlProcesser('wiki')
    cidList = [693620,2117028,2380764]
    for cid in cidList:
        pidList = sp.fetchWikiPageIndex(cid)
        cName = sp.fetWikiCategoryName(cid)
        for i in range(len(pidList)):
            if i > 8:
                break
            else:
                pid = pidList[i]
                pName = sp.fetWikiPageName(pid)
                doc = sp.fetWikiPageContent(pid)
                docReverb(sp,doc,pName,cName,pid,cid)
                finish = time.clock()
                print '\n\n\n\n\n\n' + pName + ' process finished , time consumed : ' + str(finish - start) + "\n\n\n\n\n\n"















