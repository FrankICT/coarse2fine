import re
import reverb
import sqlCon
import urllib2



class paraPrc:
    def __init__(self,txt):
        self.txt = txt
        self.sp = sqlCon.sqlProcesser('wiki')

    def subjectModify(self,subject):
        subject = subject.lower()
        subject = self.sp.paraFilter(subject)
        subPartList = subject.split('_')
        retTxt = self.txt.replace(subject.replace('_',' '),subject)
        for subPart in subPartList:
            subPart = ' ' + subPart + ' '
            if len(subPart) < 2:
                continue
            if subPart in retTxt:
                retTxt = retTxt.replace(subPart,' ' + subject + ' ')
        return retTxt

    def extractEntity(self):
        entList = []
        pat = re.compile("\[\[[^\[\]]+\]\]")
        rawStrList = pat.findall(self.txt)
        rawStrList = list(set(rawStrList))
        for rawStr1 in rawStrList:
            rawStr2 = rawStr1[2:-2]
            if rawStr2.startswith('Category:'):
                continue
            if '|' in rawStr2:
                rawStr2 = rawStr2.split('|')[0]
            if rawStr2.find('.') != -1:
                continue
            entList.append(rawStr2.replace(' ','_'))
        return entList



class sentPrc:
    def __init__(self,sent):
        self.sent = sent
        self.rawSent = self.sent.replace("[[","").replace("]]","")
        self.rvb = reverb.reverb(self.rawSent)
        self.entList = []
        self.entPreDic = {}
        pat = re.compile("\[\[[^\[\]]+\]\]")
        for item in pat.findall(self.sent):
            self.entList.append(item[2:-2])

    def reverb(self):
        self.rvb.postag()
        self.rvb.vChunking()
        self.rvb.vpChunking()
        self.rvb.npChunking()
        self.rvb.extract()
        if self.rvb.extraction != []:
            for trans in self.rvb.extraction:
                for ent in self.entList:
                    if ent.lower() in trans[0] or ent.lower() in trans[2]:
                        self.entPreDic[ent] = trans[1]



class infoPrc:

    def __init__(self,txt):
        self.txt = txt
        self.infoBox = []
        self.attrList = []

    def infoBoxCut(self):
        con = self.txt.split('\n')
        start = 0
        end = 0
        for i in range(len(con)):
            line = con[i]
            if line.startswith('{{Infobox'):
                start = i
            if line == '}}':
                end = i
            if end > start:
                self.infoBox = con[start + 1:end]
                break

    def findAttr(self):
        self.infoBoxCut()
        pat1 = re.compile('\|[^=]+=')
        pat2 = re.compile('[0-9]')
        attrList = []
        for line in self.infoBox:
            se = pat1.search(line)
            if se != None:
                rawStr = se.group()[1:].lower()
                attr = rawStr.replace(' ','')
                attr = attr.replace('=','')
                if 'templates' in attr:
                    continue
                if 'image' in attr:
                    continue
                if 'caption' in attr:
                    continue
                if pat2.search(attr) != None:
                    continue
                attrList.append(attr)
        self.attrList = attrList


class pagePrc:
    def __init__(self,name):
        self.name = name
        self.prefix = 'https://en.wikipedia.org/wiki/Category:'
        self.url = self.prefix + name

    def findSubCate(self,url=''):
        print url
        subCateUrlList = []
        if url == '':
            url = self.url
        con = urllib2.urlopen(url).read()
        pat1 = re.compile("<a class=\"CategoryTreeLabel[^<>]+")
        for rec in pat1.findall(con):
            start = rec.find('Category:')
            end = len(rec)
            subCateUrl = self.prefix + rec[start + 9:end-1]
            subCateUrlList.append(subCateUrl)
        if subCateUrlList == []:
            return [url]
        else:
            retList = [url]
            for subCateUrl in subCateUrlList:
                retList += self.findSubCate(subCateUrl)
            return retList





def findSubCate(url=''):
    prefix = 'https://en.wikipedia.org/wiki/Category:'
    subCateUrlList = []
    con = urllib2.urlopen(url).read()
    pat1 = re.compile("<a class=\"CategoryTreeLabel[^<>]+")
    for rec in pat1.findall(con):
        start = rec.find('Category:')
        end = len(rec)
        subCateUrl = prefix + rec[start + 9:end-1]
        subCateUrlList.append(subCateUrl)
    if subCateUrlList == []:
        return [url]
    else:
        retList = [url]
        for subCateUrl in subCateUrlList:
            retList += findSubCate(subCateUrl)
        return retList




