import sqlCon
import numpy as np
from sklearn.svm import SVC
from sklearn import cross_validation

# American_drama_television_series   cid = 13590818
class fVecGen4Attr:
    def __init__(self,cid = 13590818):
        self.cid = cid
        self.sp = sqlCon.sqlProcesser('wiki')
        print 'generating pidList...'
        self.pidList = self.sp.fetWikiPidlistGivenCidRecur(cid)
        print 'generating fetAttrList...'
        self.fetAttrList()
        print 'generating fetAttrValueDic...'
        self.fetAttrValueDic()
        print 'fVecGen4Attr initialization completed!'

    def fetAttrList(self):
        attrList = []
        selSql = 'select distinct(attr) from attr_value where pid = %s'
        for pid in self.pidList:
            self.sp.cur.execute(selSql,pid)
            selRes = self.sp.cur.fetchall()
            for rec in selRes:
                attrList.append(rec[0].lower())
        self.attrList = list(set(attrList))

    def fetAttrValueDic(self):
        attrValueDic = {}
        selSql = 'select distinct(value) from attr_value where attr = %s and pid in %s'
        for attr in self.attrList:
            self.sp.cur.execute(selSql,(attr,self.pidList))
            selRes = self.sp.cur.fetchall()
            for rec in selRes:
                if rec[0] != '':
                    if attrValueDic.has_key(attr):
                        attrValueDic[attr].append(rec[0])
                    else:
                        attrValueDic[attr] = [rec[0]]
        self.attrValueDic = attrValueDic

    def featureGen(self,attr):
        coverage = self.calCoverage(attr)
        valueCnt = self.calValueCnt(attr)
        vMean,vVar,vMean30,vMean60 = self.calValueData(attr)
        iaf = self.calGenerality(attr)
        fVec = np.array([coverage,valueCnt,vMean,vVar,vMean30,vMean60,iaf])
        return fVec

    # indicate if a attribute is closely related to a category
    def calCoverage(self,attr):
        selSql1 = 'select distinct(pid) from attr_value where attr = %s and pid in %s'
        attrCnt = self.sp.cur.execute(selSql1,(attr,self.pidList))
        selSql2 = 'select distinct(pid) from attr_value where id > %s and pid in %s'
        cnt = self.sp.cur.execute(selSql2,(0,self.pidList))
        return attrCnt/float(cnt+1)

    # how many values does an attribute have
    # indicate if values in the category can be clustered
    def calValueCnt(self,attr):
        cnt = len(self.attrValueDic[attr])
        return cnt/float(len(self.pidList)+1)

    # indicate if values in the category can be clustered
    # return
    # 1.the expectation of all # of values
    # 2.the varience of all # of values
    # 3.the expectation of # of values that rank in the top 30%
    # 4.the expectation of # of values that rank in the top 60%
    def calValueData(self,attr):
        selSql1 = 'select distinct(pid) from attr_value where pid in %s and attr = %s'
        selSql2 = 'select count(pid) from attr_value where pid in %s and attr = %s and value = %s'
        tcnt = self.sp.cur.execute(selSql1,(self.pidList,attr))
        valueArray = []
        for value in self.attrValueDic[attr]:
            self.sp.cur.execute(selSql2,(self.pidList,attr,value))
            vcnt = self.sp.cur.fetchall()[0][0]
            valueArray.append(vcnt)
        valueArray.sort(reverse=True)
        valueArray = np.array(valueArray)
        top30 = int(len(valueArray)*0.3)
        top60 = top30 * 2
        valueArrayTop30 = valueArray[:top30]
        valueArrayTop60 = valueArray[:top60]
        if len(valueArrayTop30) == 0:
            mean30 = 1.0
            mean60 = 1.0
        else:
            mean30 = valueArrayTop30.mean()
            mean60 = valueArrayTop60.mean()
        return valueArray.mean()/float(tcnt+1),valueArray.var(),mean30,mean60

    # indicate if an attribute is unique enough
    def calGenerality(self,attr):
        selSql1 = 'select distinct(pid) from attr_value where attr = %s'
        selSql2 = 'select distinct(pid) from attr_value where pid in %s and attr = %s'
        tcnt = self.sp.cur.execute(selSql1,(attr))
        pcnt = self.sp.cur.execute(selSql2,(self.pidList,attr))
        iaf = np.log(tcnt/float(pcnt+1))
        return iaf

    def main(self):
        file = open('test.txt','r')
        con = file.readlines()
        file.close()
        attrList = []
        XList = []
        yList = []
        for line in con:
            try:
                ls = line.split(' ')
                attrList.append(ls[0])
                XList.append(self.featureGen(ls[0]))
                yList.append(ls[1])
            except:
                print line
        return XList,yList

        # clf = SVC(kernel='linear')
        # X_train0, X_test0, y_train0, y_test0 = cross_validation.train_test_split(self.data,self.target,test_size=0.4,random_state=0)
        # X_train1, X_test1, y_train1, y_test1 = cross_validation.train_test_split(self.data,self.target,test_size=0.4,random_state=1)
        # X_train2, X_test2, y_train2, y_test2 = cross_validation.train_test_split(self.data,self.target,test_size=0.4,random_state=0)
        # clf.fit(X_train0,X_test0)
        # pred0 = clf.predict(X_test0)
        # test(pred0,y_test0)



def test(prediction,testy):
    tp = 0
    fp = 0
    tn = 0
    for i in range(len(prediction)):
        py = prediction[i]
        ty = testy[i]
        if py == 1 and ty == 1:
            tp += 1
        elif py == 1 and ty == 0:
            fp += 1
        elif py == 0 and ty == 1:
            tn += 1
    print 'precision : ' + str(tp/float(tp + fp))
    print 'recall : ' + str(tp/float(tp + tn))





