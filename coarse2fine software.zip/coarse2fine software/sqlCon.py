import pymysql
from nltk.stem.porter import PorterStemmer
import reverb
import time
import annex
import txtPrc
from psr import *
import bgr

class sqlProcesser:
    def __init__(self,db = 'wiki'):
        if db == "":
            db = "word"
        try:
            conn = pymysql.connect(host = 'localhost',user = 'root', password = 'knowledge',port = 3306)
            conn.select_db(db)
            cur = conn.cursor()
        except:
            print "mysqldb error"
        self.conn = conn
        self.cur = cur
        if db == 'word':
            self.wordDic = self.fetchWordDic()

    def storeWord2Set(self,con):
        rawWordList = con.split(' ')
        wordSet = set()
        porter = PorterStemmer()
        word = ""
        for rawWord in rawWordList:
            try:
                word = porter.stem(rawWord)
            except:
                print "error : " + rawWord
            word = word.lower()
            if word.isalpha():
                wordSet.add(word)
        return wordSet

    def storeWordSet2DB(self,wordSet,tableName):
        selSql = "select wordstr from " + tableName
        insSql = "insert into "+ tableName + "(wordstr) values(%s)"
        self.cur.execute(selSql)
        selectRes = self.cur.fetchall()
        dbWordList = []
        for rec in selectRes:
            dbWordList.append(rec[0])
        for word in wordSet:
            if word not in dbWordList:
                try:
                    self.cur.execute(insSql,(word))
                    self.conn.commit()
                except:
                    print "db input error : " + word

    def storeReverbDic2DB(self,str,tableName):
        if tableName == 'entity':
            strName = 'estr'
            contName = 'econt'
        elif tableName == 'predicate':
            strName = 'pstr'
            contName = 'pcont'
        else:
            print 'storeReverbDic2DB input error'
        selSql = "select " + contName + " from " + tableName + " where " + strName + " = %s"
        insSql = "insert into " + tableName + "(" + strName + "," + contName + ") values (%s,%s)"
        updSql = "update " + tableName + " set " + contName + " = %s where " + strName + " = %s"
        self.cur.execute(selSql,str)
        selectRes = self.cur.fetchall()
        if len(selectRes) > 0:
            if selectRes[0][0] == None:
                cont = 0
            else:
                cont = int(selectRes[0][0])
            cont += 1
            self.cur.execute(updSql,(cont,str))
            self.conn.commit()
        else:
            try:
                self.cur.execute(insSql,(str,1))
                self.conn.commit()
            except:
                print "reverb db input error : " + str

    def storeTriple2DB(self,pid,cid,pName,cName,sub,pre,obj):
        insSql = "insert into triple (pid,cid,pname,cname,sub,pre,obj) values (%s,%s,%s,%s,%s,%s,%s)"
        try:
            self.cur.execute(insSql,(pid,cid,pName,cName,sub,pre,obj))
            self.conn.commit()
        except:
            print "reverb triple input error : " + sub + "," + pre + "," + obj

    def fetchWordDic(self):
        selSql = "select wordstr from word"
        self.cur.execute(selSql)
        selectRes = self.cur.fetchall()
        rvb = reverb.reverb('')
        wordDic = {}
        for word in selectRes:
            word = rvb.wordFilter(word)
            wordDic[word[0]] = 0
        return wordDic





    def fetchWordDic(self):
        self.conn.select_db('new_extraction')
        selSql = "select wordstr from word"
        self.cur.execute(selSql)
        selRes = self.cur.fetchall()
        wordStr = ''
        for rec in selRes:
            wordStr += rec[0] + ' '
        return wordStr

    def fetReverbPreDic(self):
        self.conn.select_db('new_extraction')
        selSql = "select pstr from predicate"
        self.cur.execute(selSql)
        selRes = self.cur.fetchall()
        list = []
        for rec in selRes:
            list.append(rec[0])
        dict = {}
        for item in list:
            dict[item] = 0
        return dict

    def fetReverbEntDic(self):
        self.conn.select_db('new_extraction')
        selSql = "select estr from entity"
        self.cur.execute(selSql)
        selRes = self.cur.fetchall()
        list = []
        for rec in selRes:
            list.append(rec[0])
        dict = {}
        for item in list:
            dict[item] = 0
        return dict

    def fetTripleList(self):
        self.conn.select_db('new_extraction')
        selSql = "select sub,pre,obj from triple"
        self.cur.execute(selSql)
        selRes = self.cur.fetchall()
        return selRes

    def fetPidList(self):
        self.conn.select_db('new_extraction')
        selSql = "select distinct pid from triple"
        self.cur.execute(selSql)
        selRes = self.cur.fetchall()
        pidList = []
        for rec in selRes:
            pidList.append(rec[0])
        return pidList

    def fetCid(self,pid):
        self.conn.select_db('new_extraction')
        selSql = "select distinct cid from triple where pid = %s"
        self.cur.execute(selSql,pid)
        selRes = self.cur.fetchall()
        return selRes[0][0]

    def fetWikiCidWithCname(self,cName):
        self.conn.select_db('wiki')
        selSql = "SELECT * FROM category WHERE name = %s"
        self.cur.execute(selSql,cName)
        selRes = self.cur.fetchall()
        if selRes == ():
            print 'can\'t find cid for name : ' + cName
            return -1
        return selRes[0][0]

    def fetWikiPnameWithPid(self,pid):
        # self.conn.select_db('wiki')
        selSql = "SELECT name FROM page WHERE id = %s"
        self.cur.execute(selSql,pid)
        selRes = self.cur.fetchall()
        if selRes != ():
            return selRes[0][0]
        else:
            print 'no name'

    def fetWikiCnameGivenCid(self,cid):
        try:
            selSql = "SELECT name FROM category WHERE id = %s"
            self.cur.execute(selSql,cid)
            selRes = self.cur.fetchall()
            return selRes[0][0]
        except:
            print 'fetWikiCnameGivenCid error, cid : ' + str(cid)
            return 0

    def fetWikiPidlistGivenCid(self,cid):
        self.conn.select_db('wiki')
        selSql = "SELECT * FROM category_pages WHERE id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        retList = []
        for item in selRes:
            retList.append(item[1])
        self.pidList = retList
        return retList



    def fetWikiPidlistGivenCidRecur(self,cid):
        pidSet = set()
        for pid in self.fetchWikiPageIndex(cid):
            pidSet.add(pid)
        subCidList =  self.fetWikiSubcategoryIndexRecur(cid)
        for subCid in subCidList:
            newPidList = self.fetchWikiPageIndex(subCid)
            for pid in newPidList:
                pidSet.add(pid)
        pidList = list(pidSet)
        return pidList

    def fetWikiCidlistWithPid(self,pid):
        selSql = "select pages from page_categories where id = %s"
        self.cur.execute(selSql,pid)
        selRes = self.cur.fetchall()
        cidList = []
        for item in selRes:
            cidList.append(item[0])
        return cidList

    def fetWikiMomCidlistWithCid(self,cid):
        selSql = "select id from category_inlinks where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        cidList = []
        for item in selRes:
            cidList.append(item[0])
        return cidList

    def fetWikiCategoryinLinks(self,cid):
        selSql = "select inLinks from category_inlinks where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        cidList = []
        for item in selRes:
            cidList.append(item[0])
        return cidList

    def fetWikiCategoryoutLinks(self,cid):
        selSql = "select outLinks from category_outlinks where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        cidList = []
        for item in selRes:
            cidList.append(item[0])
        return cidList

    def buildUpLinks(self,cid,subLists,dicDown):
        inlinks = self.fetWikiCategoryoutLinks(cid)
        for item in inlinks:
            for subList in subLists:
                if item in subList:
                    dicDown[cid] = item
                    break
        return dicDown

    def fetWikiSubCategoryIndexLimitRecur(self,cid,cidSet = set([]),level = 2):
        if level == 0:
            return []
        subCidList = self.fetWikiSubcategoryIndex(cid)
        for subCid in subCidList:
            if subCid in cidSet:
                continue
            else:
                cidSet.add(subCid)
                subCidListNew = self.fetWikiSubCategoryIndexLimitRecur(subCid,cidSet,level-1)
                subCidListNew = self.wikiCateFilter(subCidListNew)
                subCidList += subCidListNew
                cidSet = cidSet.union(set(subCidListNew))
        return list(set(subCidList))

    def fetWikiSubcategoryIndexRecur(self,cid,cidSet = set([])):
        # pattern = re.compile('_by_')
        selSql = "select outLinks from category_outlinks where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        subCidList = []
        for item in selRes:
            subCidList.append(item[0])
        for subCid in subCidList:
            if subCid in cidSet:
                continue
            else:
                cidSet.add(subCid)
                subCidListNew = self.fetWikiSubcategoryIndexRecur(subCid,cidSet)
                subCidListNew = self.wikiCateFilter(subCidListNew)
                subCidList += subCidListNew
        return list(set(subCidList))



    def fetWikiPidlistGivenCidRecur(self,cid,cidSet = set([])):
        cidList = [cid]
        pidList = []
        cidList += self.fetWikiSubCategoryIndexLimitRecur(cid,level=1)
        cidList = self.wikiCateFilter(cidList)
        for cid in cidList:
            pidList += self.fetWikiPidlistGivenCid(cid)
        pidSet = set(pidList)
        self.pidList = list(pidSet)
        return self.pidList

    def fetWikiPidCntGivenCidRecur(self,cid,cidSet = set([])):
        cidList = [cid]
        pidList = []
        cidList += self.fetWikiSubCategoryIndex(cid)
        cidList = self.wikiCateFilter(cidList)
        for cid in cidList:
            pidList += self.fetWikiPidlistGivenCid(cid)
        pidSet = set(pidList)
        return list(pidSet)



    def fetWikiPidlistGivenCid2Level(self,cid):
        selSql = "select outLinks from category_outlinks where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        subCidList = [cid]
        for item in selRes:
            subCidList.append(item[0])
        pidList = []
        for subCid in subCidList:
            pidList += self.fetWikiPidlistGivenCid(subCid)
        pidList = list(set(pidList))
        self.pidList = pidList
        return pidList



    def fetWikiSubcategoryIndex(self,cid):
        selSql = "select outLinks from category_outlinks where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        cidList = []
        for item in selRes:
            cidList.append(item[0])
        return cidList

    def fetWikiCateInlinks(self,cid):
        selSql = "select inLinks from category_inlinks where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        cidList = []
        for item in selRes:
            cidList.append(item[0])
        return cidList


    def fetWikiCatePage(self,cid):
        selSql = "select pages from category_pages where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        pidList = []
        for item in selRes:
            pidList.append(item[0])
        return pidList

    def fetWikiCategoryName(self,cid):
        selSql = "select name from category where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchone()
        name = (selRes[0])
        return name

    def fetchWikiPageIndex(self,cid):
        selSql = "select pages from category_pages where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        pidList = []
        for item in selRes:
            pidList.append(item[0])
        return pidList

    def fetWikiPageContent(self,pid):
        selSql = "select text from page where id = %s"
        self.cur.execute(selSql,pid)
        selRes = self.cur.fetchone()
        doc = selRes[0]
        return doc

    def fetWikiPageName(self,pid):
        selSql = "select name from page where id = %s"
        self.cur.execute(selSql,pid)
        selRes = self.cur.fetchone()
        name = (selRes[0])
        return name

    def fetWikiSubCidCnt(self,cid):
        selSql = "select count(*) from category_outlinks where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchone()
        cnt = (selRes[0])
        return int(cnt)

    def fetWikiSubPidCnt(self,cid):
        selSql = "select count(*) from category_pages where id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchone()
        cnt = (selRes[0])
        return int(cnt)

    def fetWikiPageOutlinks(self,pid):
        selSql = "select outLinks from page_outlinks where id = %s"
        self.cur.execute(selSql,pid)
        selRes = self.cur.fetchall()
        pidList = []
        for item in selRes:
            pidList.append(item[0])
        return pidList

    def fetWikiCateDistance(self,cid1,cid2):
        momCate1 = set(self.wikiCateFilter(self.fetWikiMomCidGivenCid(cid1)))
        momCate2 = set(self.wikiCateFilter(self.fetWikiMomCidGivenCid(cid2)))
        subCate1 = set(self.wikiCateFilter(self.fetWikiSubcategoryIndex(cid1)))
        subCate2 = set(self.wikiCateFilter(self.fetWikiSubcategoryIndex(cid2)))
        ent1 = set(self.fetWikiPidlistGivenCid(cid1))
        ent2 = set(self.fetWikiPidlistGivenCid(cid2))
        a = 2
        b = 2
        c = 1
        cateSimilarity = len(momCate1.intersection(momCate2))/(1.0*len(momCate1.union(momCate2))+1)
        subSimilarity = len(subCate1.intersection(subCate2))/(1.0*len(subCate1.union(subCate2))+1)
        entSimilarity = len(ent1.intersection(ent2))/(1.0*len(ent1.union(ent2))+1)
        similarity = a * cateSimilarity + b * entSimilarity + c * subSimilarity
        return similarity


    # old version
    def fetWikiCateDistanceOld(self,cid1,cid2):
        if cid1 == cid2:
            return [0,0,cid1]
        cDic1 = {0:[cid1]}
        cDic2 = {0:[cid2]}
        cMomCate1 = set([cid1])
        cMomCate2 = set([cid2])
        for i in range(1,10):
            for cid in cDic1[i-1]:
                newMomCate = self.fetWikiMomCidGivenCid(cid)
                if newMomCate == []:
                    return 10,10,[]
                if cDic1.has_key(i):
                    cDic1[i] += newMomCate
                else:
                    cDic1[i] = newMomCate
                cMomCate1.update(newMomCate)
            for cid in cDic2[i-1]:
                newMomCate = self.fetWikiMomCidGivenCid(cid)
                if newMomCate == []:
                    return 10,10,[]
                if cDic2.has_key(i):
                    cDic2[i] += newMomCate
                else:
                    cDic2[i] = newMomCate
                cMomCate2.update(newMomCate)

            intersectCid = list(cMomCate1.intersection(cMomCate2))
            intersectCid = self.wikiCateFilter(intersectCid)
            if intersectCid != []:
                # print intersectCid[0]
                for key in cDic1.keys():
                    if intersectCid[0] in cDic1[key]:
                        path1 = key
                        break
                for key in cDic2.keys():
                    if intersectCid[0] in cDic2[key]:
                        path2 = key
                        break
                # print path1,path2
                return path1,path2,intersectCid

    def fetClusDistance(self,clus1,clus2):
        totalDis = 0
        edgeCnt = 0.0
        for cid1 in clus1:
            for cid2 in clus2:
                totalDis += self.fetWikiCateDistance(cid1,cid2)
                edgeCnt += 1
                # print 'cid1:' + self.fetWikiCnameGivenCid(cid1) + ' cid2:' +  self.fetWikiCnameGivenCid(cid2) + ' : ' + str(self.fetWikiCateDistance(cid1,cid2))
        return totalDis / edgeCnt

    def wikiCateFilter(self,cidList):
        filterList = [39217706,39217570,15961454,35740709,39217581,7361045,39217751,35505592,\
                      30176254,23823120,33429911,39217578,6239522,40662315,14105005,1036222,\
                      1536902,7345184,10837655,9329647,37500101,\
                      1052752,38576607,3782398,4182385]
        patStrList = ["Articles_","_deaths","_articles_","_births","_errors","Wiki",\
                      "category_","_stubs","ategories","Pages_","_pages_","_articles",\
                      "y_dates_from_","_games","software",'isambiguation_pages','[0-9]{4}',\
                      'Singlechart','infobox','terminology','parameters','disputes',\
                      'invention','Languages_with','Chemboxes','_listed_on_','_Stock_Exchange',\
                      'ehicles','Drugboxes','eobox_','Lists_of']
        patList = []
        for patStr in patStrList:
            patList.append(re.compile(patStr))
        for item in filterList:
            if item in cidList:
                cidList.remove(item)
        for cid in cidList:
            cname = self.fetWikiCnameGivenCid(cid)
            for pat in patList:
                if pat.search(cname) != None:
                    try:
                        cidList.remove(cid)
                    except:
                        pass
        return cidList

    def wikiCateFilter4Dic(self,cidDic):
        filterList = [39217706,39217570,15961454,35740709,39217581,7361045,39217751,35505592,\
                      30176254,23823120,33429911,39217578,6239522,40662315,14105005,1036222,\
                      1536902,7345184,10837655,9329647,37500101,\
                      1052752,3782398,4182385]
        patStrList = ["Articles_","_deaths","_articles_","_births","_errors","Wiki",\
                      "category_","_stubs","ategories","Pages_","_pages_","_articles",\
                      "y_dates_from_","_games","software",'isambiguation','[0-9]{4}',\
                      'Singlechart','infobox','terminology','parameters','disputes',\
                      'invention','Languages_with','Chemboxes','_listed_on_','_Stock_Exchange'\
                      'ehicles','Drugboxes','eobox_','Lists_of']
        patList = []
        for patStr in patStrList:
            patList.append(re.compile(patStr))
        for item in filterList:
            if item in cidDic.keys():
                cidDic.pop(item)
        for cid in cidDic.keys():
            cname = self.fetWikiCnameGivenCid(cid)
            for pat in patList:
                if pat.search(cname) != None:
                    cidDic.pop(cid)
                    break
        return cidDic

    def fetWikiMomCidGivenCid(self,cid):
        self.conn.select_db('wiki')
        selSql = "SELECT inLinks FROM category_inlinks WHERE id = %s"
        self.cur.execute(selSql,cid)
        selRes = self.cur.fetchall()
        retList = []
        for item in selRes:
            retList.append(item[0])
        return retList

    def fetWikiMomCidGivenPid(self,pid):
        self.conn.select_db('wiki')
        selSql = "SELECT pages FROM page_categories WHERE id = %s"
        self.cur.execute(selSql,pid)
        selRes = self.cur.fetchall()
        retList = []
        for item in selRes:
            retList.append(item[0])
        return retList

    def fetWikiPidOutLinkListGivenPid(self,pid):
        selSql = "select outLinks from page_outlinks where id = %s"
        self.cur.execute(selSql,pid)
        selRes = self.cur.fetchall()
        retList = []
        for item in selRes:
            retList.append(item[0])
        return retList

    def fetWikiRelatedPidGivenPid(self,pid):
        relatedPidList = []
        pidCon = self.fetWikiPageContent(pid)
        # cut the content
        if len(pidCon) > 5000:
            pidCon = pidCon[:5000]
        prc = txtPrc.paraPrc(pidCon)
        nameList = prc.extractEntity()
        for name in nameList:
            pid = self.fetWikiPidGivenPName(name)
            if pid == None:
                pass
            elif pid == -1:
                pass
            else:
                relatedPidList.append(pid)
        return relatedPidList

    def fetWikiPidFromNamePidDic(self,name):
        selSql = "SELECT pid FROM name_pid WHERE pname = %s"
        self.cur.execute(selSql,name)
        selRes = self.cur.fetchall()
        if selRes != ():
            return selRes[0][0]
        elif selRes == ():
            return None
            # print 'DB query error! can\'t find word : ' + name


    def dicCountFilter(self,attrDic,Count):    # given a dictionary that may contain more than 1000, output a dictionary that contains atmost 1000 elements that are highest in value
        if len(attrDic) < Count:
            return attrDic
        valueList = attrDic.values()
        valueList.sort(reverse=True)
        cutPoint = valueList[Count-1]
        for key in attrDic.keys():
            if attrDic[key] < cutPoint + 1:
                attrDic.pop(key)
        return attrDic



    def fetWikiPotentialAttrGivenCid1level(self,cid):
        anx = annex.anx()
        t1 = time.clock()
        valueDic = {}       # key: value (entity)           content: how many times does the value occur
        valuePidDic = {}    # key: value (entity)           content: pid
        attrDic = {}        # key: attribute (category)     content: how many times does the attribute occur
        attrValueDic = {}   # key: attribute (category)     content: value
        pidList = self.pidList
        for pid in pidList:
            valueList = self.fetWikiRelatedPidGivenPid(pid)
            for value in valueList:
                if valuePidDic.has_key(value):
                    valuePidDic[value].append(pid)
                else:
                    valuePidDic[value] = [pid]
                if valueDic.has_key(value):
                    valueDic[value] += 1
                else:
                    valueDic[value] = 1
        valueDic = self.dicCountFilter(valueDic,3000) #dic1
        print 'step1 time consumed:'
        t2 = time.clock()
        print(t2 - t1)
        for item in valueDic.keys():   # len(itemList) 100
            potenAttrList = self.fetWikiMomCidGivenPid(item)
            for attrid in potenAttrList:    # len(attrList) 30
                if attrid in attrValueDic.keys():
                    attrValueDic[attrid].append(item)
                else:
                    attrValueDic[attrid] = [item]
                if attrid in attrDic.keys():
                    attrDic[attrid] += 1
                else:
                    attrDic[attrid] = 1
        attrDic = self.wikiCateFilter4Dic(attrDic)
        attrValueDic = self.wikiCateFilter4Dic(attrValueDic)
        attrDic = self.dicCountFilter(attrDic,1200)
        t3 = time.clock()
        print 'step2 time consumed:'
        print(t3-t2)
        dicKeys = attrValueDic.keys()
        for dicKey in dicKeys:
            if dicKey not in attrDic:
                attrValueDic.pop(dicKey)
        valuePidDic = anx.valuePidDicFilter(valuePidDic,pidList)

        return attrDic,attrValueDic,valuePidDic

    def fetWikiPotentialAttrGivenCid2level(self,firAttrDic):
        secAttrDic = {}
        upDownDic = {}
        for firKey in firAttrDic.keys():
            momCateList = self.fetWikiMomCidGivenCid(firKey)
            for secKey in momCateList:
                if upDownDic.has_key(secKey):
                    upDownDic[secKey].append(firKey)
                else:
                    upDownDic[secKey] = [firKey]
                if secAttrDic.has_key(secKey):
                    secAttrDic[secKey] += firAttrDic[firKey]
                else:
                    secAttrDic[secKey] = firAttrDic[firKey]
        secAttrDic = self.dicCountFilter(secAttrDic,500)
        secAttrDic = self.wikiCateFilter4Dic(secAttrDic)
        dicKeys = upDownDic.keys()
        for dicKey in dicKeys:
            if dicKey not in secAttrDic:
                upDownDic.pop(dicKey)
        return secAttrDic,upDownDic



    def tempTest(self):
        # cid = 706543   # machine learning
        # cid = 953043   # Smartphones   very good!
        cid = 12398791   # Touchscreen_mobile_phones    only 346 entities less noise,less computation time
        # according to experiment, when the number of attrbutes is less than 2500, the speed can be guaranteed.

        # first, make a dictionary(dic) that contains all potential candidate attributes
        # pidList = self.fetWikiPidlistGivenCid(cid)
        dic1,dic10,dic0Pid = self.fetWikiPotentialAttrGivenCid1level(cid)
        anx = annex.anx(dic1,dic10,dic0Pid,self.pidList)
        anx.buildCateDisMatOld()
        # anx.buildDicAttrValue()
        bg = bgr.bg(anx,cid)
        bg.buildDicAttrValue()
        bg.writeRes()

        import matplotlib.pyplot as plt

        # new version
        cid = 12398791   # Touchscreen_mobile_phones    only 346 entities less noise,less computation time
        # according to experiment, when the number of attrbutes is less than 2500, the speed can be guaranteed.

        # first, make a dictionary(dic) that contains all potential candidate attributes
        pidList = self.fetWikiPidlistGivenCid(cid)
        dic1,dic10,dic0Pid = self.fetWikiPotentialAttrGivenCid1level(cid)
        # anx = annex.anx(dic1,dic10,dic0Pid,pidList)

        dic2,dic21 = self.fetWikiPotentialAttrGivenCid2level(dic1)
        dic3,dic32 = self.fetWikiPotentialAttrGivenCid2level(dic2)
        # dic4,dic43 = self.fetWikiPotentialAttrGivenCid2level(dic3)
        anx = annex.anx(dic1,dic2,dic3,dic32,dic21,dic10,dic0Pid,pidList)

        anx.buildCateDisMatOld()

        bg = bgr.bg(anx,cid)
        bg.valueScoring()
        bg.attrScoringL1()
        bg.attrClustering()



    # dic10 is attrValueDic
    # pid = 240989    yaoming
    # pid = 246185    kobe
    # pid = 240940    james





    def fetWikiPidGivenPName(self,pName):
        selSql = 'select id from page where name = %s'
        self.cur.execute(selSql,pName)
        selRes = self.cur.fetchall()
        if len(selRes) == 0:
            return -1
        else:
            return selRes[0][0]

    def fetWikiPageOutLinkCnt(self,pid):
        selSql = 'select count(*) from page_outlinks where id = %s'
        self.cur.execute(selSql,pid)
        try:
            selRes = self.cur.fetchall()
            return selRes[0][0]
        except:
            print('fetWikiPageOutLinkCnt error!')

    def fetWikiPageInLinkCnt(self,pid):
        selSql = 'select count(*) from page_inlinks where id = %s'
        self.cur.execute(selSql,pid)
        try:
            selRes = self.cur.fetchall()
            return selRes[0][0]
        except:
            print('fetWikiPageInLinkCnt error!')




    def paraFilter(self,para):
        pattern1 = re.compile('<ref.+</ref>')
        pattern2 = re.compile('{{.+}}')
        pattern3 = re.compile('\[\[')
        pattern4 = re.compile(']]')
        pattern5 = re.compile('<!--.+-->')
        pattern6 = re.compile('<.+>')
        pattern7 = re.compile('\([^\(\)]+\)')
        pattern8 = re.compile(' +')
        para = re.sub(pattern1,'',para)
        para = re.sub(pattern2,'',para)
        para = re.sub(pattern3,'',para)
        para = re.sub(pattern4,'',para)
        para = re.sub(pattern5,'',para)
        para = re.sub(pattern6,'',para)
        para = re.sub(pattern7,'',para)
        para = para.replace("\'",'')
        para = para.replace("\'\'\'",'')
        para = para.lower()
        pattern9 = re.compile('[^a-z _]')
        para = re.sub(pattern9,'',para)
        para = re.sub(pattern8,' ',para)
        return para



    def paraFilterWithCate(self,para):
        pattern1 = re.compile('<ref.+</ref>')
        pattern2 = re.compile('{{.+}}')
        pattern5 = re.compile('<!--.+-->')
        pattern6 = re.compile('<.+>')
        pattern7 = re.compile('\(.+\)')
        pattern8 = re.compile("\[\[[^\[\]]+\]\]")
        para = re.sub(pattern1,'',para)
        para = re.sub(pattern2,'',para)
        para = re.sub(pattern5,'',para)
        para = re.sub(pattern6,'',para)
        para = re.sub(pattern7,'',para)
        para = para.replace("\'",'')
        changeList = pattern8.findall(para)
        for item in changeList:
            if '|' not in item:
                continue
            else:
                endPos = item.find("|")
                newItem = item[:endPos] + ']]'
                para = para.replace(item,newItem)
        if para.startswith('!') or para.startswith('{'):
            return None
        return para

    def potentialAttrFilter(self,dic,thresh):
        remainList = []
        for key in dic.keys():
            if dic[key] < thresh:
                remainList.append(key)
        for key in remainList:
            dic.pop(key)
        return dic



    def docFilter(self,doc):
        paras = doc.split('\n')
        retParaList = []
        for para in paras:
            if len(para) < 30:
                continue
            elif para.startswith('[[Category:') or para.startswith("*") or para.startswith('<!--') or para.startswith('|')  \
                    or para.startswith(' |') or para.startswith('{{') or para.startswith('[[File:') or para.startswith('==') \
                    or para.startswith('  <!') or para.startswith('  |'):
                continue
            para = self.paraFilter(para)
            retParaList.append(para)
        return retParaList

    def infoboxFilter1(self,doc):
        start = doc.find('{{infobox')
        if start == -1:
            start = doc.find('{{Infobox')
        if start == -1:
            return ''
        reStart = start + 1
        pat = re.compile("{{|}}")
        stack = 1
        while stack > 0:
            next = pat.search(doc,reStart)
            if next == None:
                # print 'infoboxFilter1 error'
                return 'error'
            reStart = next.end()+1
            signal = next.group()
            if signal == "{{":
                stack += 1
            elif signal == "}}":
                stack -= 1
            else:
                # print 'infoboxFilter1 error!'
                return
        end = next.end()
        return doc[start+2:end-2]



    def infoboxFilter2(self,info):
        info = info.replace('<br />',',')
        pat1 = re.compile('<ref[^<]+</ref>')
        info = info.replace('\n','')
        info = re.sub(pat1,'',info)
        pat2 = re.compile('<[^\<\>]+>')
        info = re.sub(pat2,'',info)
        pat3 = re.compile('\|[^\[]+\]\]')
        info = re.sub(pat3,']]',info)
        info = psr1(info)
        pat5 = re.compile('\([^()]+\)')
        info = re.sub(pat5,'',info)
        info = info.replace(',,',',')
        info = info.replace(']][[',',')
        info = info.replace('[[','')
        info = info.replace(']]','')
        info = info.replace('\'','')
        infoList = info.split('|')
        infoList = infoList[1:]
        infoDic = {}
        for rec in infoList:
            try:
                if '=' not in rec:
                    continue
                sub,obj = rec.split('=')
                if len(sub) > 200:
                    continue
                if len(obj) > 800:
                    obj = ''
                sub = sub.replace(' ','')
                if sub == 'image':
                    continue
                if obj.startswith(' '):
                    obj = obj[1:]
                infoDic[sub] = obj
            except:
                pass
                # print 'input error : ' + rec
        return infoDic



    def insertInfoDic(self,pid,infoDic):
        insSql = 'insert into attr_value (pid,attr,value) values (%s,%s,%s)'
        for attr in infoDic.keys():
            value = infoDic[attr]
            if ',' not in value:
                try:
                    self.cur.execute(insSql,(pid,attr,psr2(value)))
                    self.conn.commit()
                except:
                    pass
                    # print "insertInfoDic input error : " + str(pid) + "," + attr + "," + value
            else:
                valueList = value.split(',')
                for valueItem in valueList:
                    if valueItem == '':
                        continue
                    try:
                        self.cur.execute(insSql,(pid,attr,psr2(valueItem)))
                        self.conn.commit()
                    except:
                        pass
                        # print "insertInfoDic input error : " + str(pid) + "," + attr + "," + valueItem




    def urlConFilter(self,urlCon):
        pat1 = re.compile("{{.+}}")
        changeList1 = pat1.findall(urlCon)
        for line in changeList1:
            urlCon = urlCon.replace(line,"")
        pat2 = re.compile("<.+>")
        changeList2 = pat2.findall(urlCon)
        for line in changeList2:
            urlCon = urlCon.replace(line,"")
        return urlCon



    def docFilterWithCate(self,doc):
        paras = doc.split('\n')
        retParaList = []
        for para in paras:
            if para.startswith('[[Category:') or para.startswith("*") or para.startswith('<!--') or para.startswith('|')  \
                    or para.startswith(' |') or para.startswith('{{') or para.startswith('[[File:') or para.startswith('==') \
                    or para.startswith('  <!') or para.startswith('  |'):
                continue
            para = self.paraFilterWithCate(para)
            if para != None and len(para) > 30:
                retParaList.append(para)
        return retParaList



    def wikiStrConverter(self,rawStr):
        cateStr = rawStr.replace('[[','')
        cateStr = cateStr.replace(']]','')
        cateStr = cateStr.replace(' ','_')
        return cateStr

    def wikiTitleFilter(self,rawStr):
        pat = re.compile('<title>[^<]+- Wikipedia')
        se = pat.search(rawStr)
        title = se.group()
        title = title.replace("<title>",'')
        title = title.replace(" - Wikipedia",'')
        title = title.replace(" ","_")
        return title

    def wikiNameFilter(self,nameStr):
        pat1 = re.compile("article")
        pat2 = re.compile("births")
        pat3 = re.compile("errors")
        pat4 = re.compile("wiki")
        pat5 = re.compile("stubs")
        pat6 = re.compile("categories")
        pat7 = re.compile('category')
        pat8 = re.compile("deaths")
        pat9 = re.compile("date")
        pat10 = re.compile("page")
        pat11 = re.compile("time")
        pat12 = re.compile("\.")
        pat13 = re.compile(":")
        patList = [pat1,pat2,pat3,pat4,pat5,pat6,pat7,pat8,pat9,pat10,pat11,pat12,pat13]
        for pat in patList:
            if pat.findall(nameStr.lower()) != []:
                return ''
        return nameStr

    def wikiNameListFilter(self,nameList):
        retList = []
        pat1 = re.compile("article")
        pat2 = re.compile("births")
        pat3 = re.compile("errors")
        pat4 = re.compile("wiki")
        pat5 = re.compile("stubs")
        pat6 = re.compile("categories")
        pat7 = re.compile('category')
        pat8 = re.compile("deaths")
        pat9 = re.compile("date")
        pat10 = re.compile("page")
        pat11 = re.compile("time")
        pat12 = re.compile("\.")
        pat13 = re.compile(":")
        pat14 = re.compile('list')
        patList = [pat1,pat2,pat3,pat4,pat5,pat6,pat7,pat8,pat9,pat10,pat11,pat12,pat13,pat14]
        for nameStr in nameList:
            permission = 0
            for pat in patList:
                if pat.findall(nameStr.lower()) != []:
                    permission += 1
            if permission == 0:
                retList.append(nameStr)
        return retList

    def cateFilter(self,rawDoc,index = 0):
        catePat = re.compile("wgCategories\":\[[^\[\]]+\]")
        cateStr = catePat.findall(rawDoc)
        if len(cateStr) == 0:
            return []
        else:
            cateStr = cateStr[0]
        cateStr = cateStr.replace("wgCategories\":[",'')
        cateStr = cateStr.replace("]",'')
        cateStr = cateStr.replace('\"','')
        cateNameList = cateStr.split(',')
        cateNameList = self.wikiNameListFilter(cateNameList)
        return cateNameList

    def entityExistFilter(self,rawStr):
        pat = re.compile("Wikipedia does not have an article with this exact name")
        if pat.findall(rawStr) != []:
            return -1
        else:
            return 1

    def insertWikiNamePidDic(self,nameStr):
        if self.wikiNameFilter(nameStr) == '':
            return
        # if the name does not accord to the standard, just pass it
        selSql = 'select * from name_pid where pname = %s'
        insSql = 'insert into name_pid (pid,pname) values (%s,%s)'
        self.cur.execute(selSql,nameStr)
        selRes = self.cur.fetchall()
        if len(selRes) > 0:
            return
        else:
            pid = self.fetWikiPidGivenPName(nameStr)
            try:
                self.cur.execute(insSql,(pid,nameStr))
                self.conn.commit()
            except:
                print 'insertWikiNamePidDic error' + str(pid) + ' ' + nameStr



    def attrRanking5(self,pidList):
        attrDic = {}
        totalCnt = 0
        infoBoxCnt = 0
        for pid in pidList:
            totalCnt += 1
            con = self.fetWikiPageContent(pid)
            ipr = txtPrc.infoPrc(con)
            ipr.findAttr()
            attrList = ipr.attrList
            if attrList != []:
                infoBoxCnt += 1
            for attr in attrList:
                if attrDic.has_key(attr):
                    attrDic[attr] += 1
                else:
                    attrDic[attr] = 1
        attrCntList = []
        for attr in attrDic.keys():
            attrCntList.append([attrDic[attr],attr])
        attrCntList.sort(reverse=True)
        writeList = []
        writeList.append('a baseline method, use INFOBOX to select proper attributes\n')
        writeList.append('infoBox coverage : ' + str(infoBoxCnt/float(totalCnt)).format() + '\n')
        for i in range(min(len(attrCntList),10)):
            item = attrCntList[i]
            attr = item[1]
            writeList.append('attribute rank No.' + str(i+1) + ' : ' + attr + '\n')
        writeList.append('\n\n\n')
        return writeList





















# 15947721 Best_Supporting_Actor_Golden_Globe_(film)_winners Brat Pitt
# 15947442 Best_Director_Golden_Globe_winners
# 21492465 Golden_Globe_Award_winners




################################################### do not delete ###################################################
def psr1(inputStr):
    pat = re.compile('{{[^{}]+}}')
    strList = pat.findall(inputStr)
    for str in strList:
        alterStr = str[2:-2]
        alterStr = alterStr[alterStr.find('|')+1:]
        alterStr = alterStr.replace('*',',')
        alterStr = alterStr.replace('|',',')
        inputStr = inputStr.replace(str,alterStr)
    return inputStr

def psr2(inputStr):
    while(inputStr.startswith(' ')):
        inputStr = inputStr[1:]
    while(inputStr.endswith(' ')):
        inputStr = inputStr[:-1]
    return inputStr
################################################### do not delete ###################################################


