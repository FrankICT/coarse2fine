import l2r
import sqlCon


def help(oldSr,newSr):
    newSr.pVecDic = oldSr.pVecDic
    newSr.cVecDic = oldSr.cVecDic
    newSr.pidTrainList = oldSr.pidTrainList
    newSr.pidTestList = oldSr.pidTestList
    newSr.trainX = oldSr.trainX
    newSr.trainy = oldSr.trainy
    newSr.cidPredictJudgeList = oldSr.cidPredictJudgeList
    newSr.clf = oldSr.clf
    newSr.cidPredictList = []
    return newSr

