import sqlCon
from sklearn.svm import SVC
from sklearn import cross_validation
import time
import txtPrc
import gensim,logging
import annex
import numpy as np


class fvecGenerater:
    def __init__(self,attrCid,cateCid,anx):
        self.attrCid = attrCid
        self.cateCid = cateCid
        self.anx = anx
        self.sp = sqlCon.sqlProcesser('wiki')

    def generateFeature(self):
        subCateCnt = len(self.sp.fetWikiSubcategoryIndex(self.attrCid))
        momCateCnt = len(self.sp.fetWikiMomCidGivenCid(self.attrCid))
        cateDis1,cateDis2 = self.sp.fetWikiCateDistance(self.attrCid,self.cateCid)
        coverage = len(self.anx.dicx[self.attrCid])/float(len(self.anx.pidList))
        relatedSubCateVar = self.anx.queryDirectChildPcntVarience(self.attrCid)
        relatedsubCateCnt = len(self.anx.queryDirectChild(self.attrCid))
        absl1,absl2,absl3,absl4 = self.abstractLevelExtractor()
        similarity = self.cateSimilarity(self.attrCid,self.cateCid)
        pidCnt,tInCnt,tOutCnt = self.pageLinkCnt(self.attrCid)
        sbMean,sbVar = self.anx.querySiblingPartitionality(self.attrCid)
        featureVec = [subCateCnt,momCateCnt,cateDis1,cateDis2,\
                      absl1,absl2,absl3,absl4,\
                      coverage,relatedsubCateCnt,relatedSubCateVar,similarity,\
                      pidCnt,tInCnt,tOutCnt,sbMean,sbVar]
        return featureVec



    def abstractLevelExtractor(self):
        totalCnt = float(len(self.anx.dicx[self.attrCid]))
        if self.attrCid in self.anx.dic1Pid.keys():
            p1 = len(self.anx.dic1Pid[self.attrCid])/totalCnt
        else:
            p1 = 0.0
        if self.attrCid in self.anx.dic2Pid.keys():
            p2 = len(self.anx.dic2Pid[self.attrCid])/totalCnt
        else:
            p2 = 0.0
        if self.attrCid in self.anx.dic3Pid.keys():
            p3 = len(self.anx.dic3Pid[self.attrCid])/totalCnt
        else:
            p3 = 0.0
        if self.attrCid in self.anx.dic4Pid.keys():
            p4 = len(self.anx.dic4Pid[self.attrCid])/totalCnt
        else:
            p4 = 0.0
        return p1,p2,p3,p4



    def cateSimilarity(self,cid1,cid2):
        pidList1 = self.sp.fetWikiPidlistGivenCidRecur(cid1)
        pidList2 = self.sp.fetWikiPidlistGivenCidRecur(cid2)
        pidIntersect = set(pidList1).intersection(set(pidList2))
        similarity = ((len(pidIntersect)/float(len(pidList1))) +\
                      (len(pidIntersect)/float(len(pidList2)))) / 2.0
        return similarity



    def pageLinkCnt(self,cid):
        # time1 = time.clock()
        pidList = self.sp.fetWikiPidlistGivenCidRecur(cid)
        # time2 = time.clock()
        pidCnt = len(pidList)
        tInCnt = 0
        tOutCnt = 0
        for pid in pidList:
            inCnt = self.sp.fetWikiPageInLinkCnt(pid)
            outCnt = self.sp.fetWikiPageOutLinkCnt(pid)
            tInCnt += inCnt
            tOutCnt += outCnt
        # time3 = time.clock()
        # print str(time2 - time1) + ' ' + str(time3 - time2)
        return pidCnt,tInCnt,tOutCnt








class dataLoader:

    def __init__(self,anx):
        self.file = []
        self.fileName = raw_input('please input a filename : (please don\'t incorporate suffix)')
        self.fileName += '.txt'
        self.anx = anx
        self.sp = sqlCon.sqlProcesser('wiki')
        self.startPosition = 0
        self.startNum = -1



    def inputProcess(self,inputStr):
        if inputStr == 'exit':
            print 'data input over!'
            if self.file == []:
                exit()
            else:
                self.file.close()
                exit()
        elif inputStr == 'restart':
            self.restart()
        elif inputStr == 'start':
            self.start()
        else:
            return inputStr

    def restart(self):
        file = open(self.fileName)
        con = file.readlines()
        file.close()
        line = con[len(con) - 1]
        items = line.split('   ')
        self.startPosition = int(items[0])
        self.startNum = int(items[1])
        self.start()

    def start(self):
        self.file = open(self.fileName,'w+')
        judge = 0
        i = self.startPosition
        for key in self.anx.dicx.keys():
            if self.startNum > 0:
                if key != self.startNum:
                    continue
                else:
                    self.startNum = -1
                    continue
            if judge < 0:
                continue
            cnt = len(self.anx.dicx[key])
            if cnt > 100 and judge == 0:
                judge = 1
            elif cnt < 100 and judge == 1:
                judge = 0
            else:
                continue
            outputStr =  str(i) + '   ' + str(key) + '   ' \
                  + self.sp.fetWikiCnameGivenCid(key) \
                         # + '   ' + str(len(self.anx.dicx[key])) \
                  # + '   ' + str(len(self.anx.queryDirectChild(key)))
            # print id:str(i)   cid:self.anx.dicx[key]   cname:self.sp.fetWikiCnameGivenCid(key)   pCnt:len(self.anx.dicx[key])   subCateCnt:lenlen(self.anx.queryDirectChild(key))
            print outputStr
            inputStr = raw_input('classification : ')
            classification = self.inputProcess(inputStr)
            if classification == '':
                continue
            self.file.write(outputStr + '   ' + str(classification) +'\n')
            i += 1

    def txt2List(self):
        cidList = []
        yList = []
        file = open(self.fileName,'r')
        con = file.readlines()
        file.close()
        for line in con:
            items = line.split('   ')
            try:
                cidList.append(int(items[1]))
                yList.append(int(items[3]))
            except:
                print 'imput error' +  line
        return cidList,yList



class Learner:

    def __init__(self,cateCid,cidList,target,anx):
        self.cateCid = cateCid
        self.cidList = cidList
        self.target = target
        self.y = []
        self.X = []
        self.anx = anx

    def dataGen(self):
        print 'generating training & testing data, please wait...'
        for i in range(len(self.cidList)):
            cid = self.cidList[i]
            print 'generating vec for : ' + str(cid)
            try:
                fg = fvecGenerater(cid,self.cateCid,self.anx)
                # fg = ml.fvecGenerater(cid,cateCid,anx)
                fVec =fg.generateFeature()
                self.X.append(fVec)
                self.y.append(self.target[i])
                # print str(i) + '/' + str(len(self.cidList)) + ' complete'
            except:
                print 'trainAttr loading error : ' + str(cid)
        print 'generating data complete'


        # t1 = time.clock()   38928522
        # print 'generating training & testing data, please wait...'
        # for i in range(len(self.trainAttrCidList)):
        #     trainAttr = self.trainAttrCidList[i]
        #     try:
        #         fg = fvecGenerater(trainAttr,self.cateCid,self.anx)
        #         fVec =fg.generateFeature()
        #         self.trainX.append(fVec)
        #         self.trainY.append(self.trainy[i])
        #         self.data.append(fVec)
        #         self.target.append(self.trainy[i])
        #     except:
        #         print 'trainAttr loading error : ' + str(trainAttr)
        # for i in range(len(self.testAttrCidList)):
        #     testAttr = self.testAttrCidList[i]
        #     try:
        #         fg = fvecGenerater(testAttr,self.cateCid,self.anx)
        #         fVec =fg.generateFeature()
        #         self.testX.append(fVec)
        #         self.testY.append(self.testy[i])
        #         self.data.append(fVec)
        #         self.target.append(self.testy[i])
        #     except:
        #         print 'testAttr loading error : ' + str(testAttr)
        # print 'training & testing data generated, time consumed : '
        # t2 = time.clock()
        # print t2 - t1


    def train(self):
        self.svc.fit(self.trainX,self.trainY)
    #     clf.fit(trainX,trainy)

    def predict(self):
        self.prediction = self.svc.predict(self.testX)
    #     prediction = clf.predict(testX)

    def test(self):
        correct = 0
        wrong = 0
        for i in range(len(self.testY)):
            if self.prediction[i] == self.testY[i]:
                correct += 1
            else:
                wrong += 1
        print 'correct rate : ' + str(correct/float(len(self.prediction)))

    def crossValidation(self):
        # X_train, X_test, y_train, y_test = cross_validation.train_test_split(self.data,self.target,test_size=0.4,random_state=0)
        clf = SVC()
        scores = cross_validation.cross_val_score(clf, self.X, self.target,cv=4)
        print scores



class vecLearner:
    def __init__(self,pidList):
        self.pidList = pidList
        self.sp = sqlCon.sqlProcesser()
        self.sentSet = []
        self.pidNameDic = {}
        self.pidVecDic = {}
        self.model = None

    def learn(self):
        print 'start loading data...'
        time1 = time.clock()
        for pid in self.pidList:
            doc = self.sp.fetWikiPageContent(pid)
            pName = self.sp.paraFilter(self.sp.fetWikiPnameWithPid(pid))
            if pName.endswith('_'):
                pName = pName[:-1]
            oldParas = self.sp.docFilter(doc)
            paras = []
            for para in oldParas:
                para = ' ' + para + ' '
                paras.append(para)
            self.pidNameDic[pid] = pName
            for para in paras:
                ppr = txtPrc.paraPrc(para)
                sent = ppr.subjectModify(pName)
                sent = sent.split()
                self.sentSet.append(sent)
        time2 = time.clock()
        print 'time consumed : ' + str(time2 - time1)
        print 'start generating wordVec...'
        logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
        self.model = gensim.models.Word2Vec(self.sentSet, min_count=1,size = 300,window=7)
        time3 = time.clock()
        print 'time consumed : ' + str(time3 - time2)
        for key in self.pidNameDic.keys():
            name = self.pidNameDic[key]
            if self.model.__contains__(name):
                self.pidVecDic[key] = annex.qumo(self.model.__getitem__(name))
        print  'word2vec completed!'



