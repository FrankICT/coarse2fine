import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVC
from scipy import sparse
import sqlCon
import time
import re
import cTree
import itertools



class reverbVecConverter:
    def __init__(self,cateTree = None):
        self.sp= sqlCon.sqlProcesser('new_extraction')
        self.spWiki = sqlCon.sqlProcesser('wiki')
        self.preDict = self.sp.fetReverbPreDic()
        self.entDict = self.sp.fetReverbEntDic()
        wordStr = self.sp.fetchWordDic()
        self.conV = CountVectorizer()
        self.conV.fit([wordStr])
        self.conV.stop_words = 'english'
        self.tree = cateTree


    def doc2PreEntVec(self,pid):
        tripleList = self.sp.fetTripleList()
        docPreDict = self.preDict.copy()
        docEntDict = self.entDict.copy()
        for triple in tripleList:
            sub = triple[0]
            pre = triple[1]
            obj = triple[2]
            if docEntDict.has_key(sub):
                docEntDict[sub] += 1
            if docPreDict.has_key(pre):
                docPreDict[pre] += 1
            if docEntDict.has_key(obj):
                docEntDict[obj] += 1
        return np.array(docPreDict.values()),np.array(docEntDict.values())

    def doc2WrdVec(self,pid):
        # print 'pid ' + str(pid)
        doc = self.spWiki.fetWikiPageContent(pid)
        paras = self.spWiki.docFilter(doc)
        rawDocStr = ''
        docStr = ''
        for para in paras:
            rawDocStr += para
        for char in rawDocStr:
            char = self.charFilter(char)
            docStr += char
        csrMat = self.conV.transform([docStr])
        wVec = csrMat.toarray()[0]
        wordCont = 100
        for unit in wVec:
            wordCont += unit
        wVec = 100*(wVec/float(wordCont))
        return wVec

    def doc2Vec(self,pid):
        wrdList = list(self.doc2WrdVec(pid))
        preList,entList = self.doc2PreEntVec(pid)
        preList = list(preList)
        entList = list(entList)
        fVec = np.array(wrdList + preList + entList)
        return fVec

    def charFilter(self,char):
        char = char.lower()
        pat = re.compile("[^a-z -']")
        errWordList = pat.search(char)
        if errWordList != None:
            return ''
        else:
            return char

    def fetPidList(self,cid):
        selSql = 'select distinct pid from triple where cid = %s'
        self.sp.cur.execute(selSql,cid)
        selRes = self.sp.cur.fetchall()
        pidList = []
        for item in selRes:
            pidList.append(item[0])
        return pidList



    def cateSub2PreEntVec(self,cid):
        compPidList = self.compPidFilter(self.fetPidList(cid))
        pVec = []
        eVec = []
        if compPidList == None:
            print 'empty category,cateSub2PreEntVec failed'
            return pVec,eVec
        for pid in compPidList:
            # only to avoid including test data
            if pid%3 == 0:
                continue
            # only to avoid including test data
            nPVec,neVec = self.doc2PreEntVec(pid)
            if pVec == [] or eVec == []:
                pVec = nPVec
                eVec = neVec
            else:
                pVec += nPVec
                eVec += neVec
        return pVec,eVec

    def cateSub2WrdVec(self,cid):
        # print 'cid ' + str(cid)
        compPidList = self.compPidFilter(self.fetPidList(cid))
        wVec = []
        if compPidList == []:
            print 'empty category,cateSub2WrdVec failed'
            return wVec
        for pid in compPidList:
            nwVec = self.doc2WrdVec(pid)
            if wVec == []:
                wVec = nwVec
            else:
                wVec += nwVec
        return wVec

    def catePar2FVec(self,cid,cVecDic):
        subNodeList = self.tree.nodeDic[cid].children
        cVec = []
        for child in subNodeList:
            if cVec == []:
                cVec = cVecDic[child.cid]
            else:
                cVec += cVecDic[child.cid]
        return cVec/len(subNodeList)

    def compPidFilter(self,pidList):
        compPidList = []
        for pid in pidList:
            if pid % 4 == 0:
                compPidList.append(pid)
        return compPidList


    def trainPidFilter(self,pidList):
        compPidList = []
        for pid in pidList:
            if pid % 4 == 1 or pid % 4 == 2 or pid % 4 == 3:
                compPidList.append(pid)
        return compPidList

    def testPidFilter(self,pidList):
        compPidList = []
        for pid in pidList:
            if pid % 4 == 0:
                compPidList.append(pid)
        return compPidList


class svmRank:
    def __init__(self):
        print 'initiation start'
        start = time.clock()
        self.loadCateTreeData()
        self.sp = sqlCon.sqlProcesser('new_extraction')
        self.pidList =self.sp.fetPidList()
        self.conV = reverbVecConverter(self.cateTree)
        # filled in dataGen
        self.pVecDic = {}
        self.cVecDic = {}
        self.pidTrainList = []
        self.pidTestList = []
        self.trainX = []
        self.trainy = []
        self.cidPredictJudgeList = []
        # filled in svmTrain
        self.clf = SVC()
        # filled in svmPredict
        self.cidPredictList = []
        finish = time.clock()
        print 'initiation complete'
        print 'initiation time consumed : ' + str(finish - start)

    def loadCateTreeData(self):
        self.cid1 = 2118729 # Category:Art_media

        self.cid2 = 2012004 # Category:Film
        self.cid3 = 42321809 # Category:Film_industry
        self.cid4 = 21762689 # Category:Film_competitions
        self.cid5 = 1891545 # Category:Film_characters

        self.cid6 = 717207 # Category:Photography
        self.cid7 = 1426189 # Category:Digital_photography
        self.cid8 = 8066037 # Category:Photography_equipment
        self.cid9 = 693858 # Category:Photographers

        self.cid10 = 708984 # Category:Architecture
        self.cid11 = 3191876 # Category:Architecture_awards
        self.cid12 = 28030677 # Category:Sustainable_architecture
        self.cid13 = 8769619 # Category:Building_technology


        self.cid14 = 707606 # Category:Painting
        self.cid15 = 693620 # Category:Painters
        self.cid16 = 2117028 # Category:Painting_materials
        self.cid17 = 2380764 # Category:Painting_techniques

        self.cateTree = self.cTreeGrowth()

        self.pageCidList = [self.cid3,self.cid4,self.cid5,self.cid7,self.cid8,self.cid9,self.cid11,self.cid12,self.cid13,self.cid15,self.cid16,self.cid17]
        self.cidList = [self.cid1,self.cid2,self.cid3,self.cid4,self.cid5,self.cid6,self.cid7,self.cid8,self.cid9,self.cid10,self.cid11,self.cid12,self.cid13,self.cid14,self.cid15,self.cid16,self.cid17]
        self.cidList.reverse()

    def featureGen(self,id,pc):
        if pc == 'p':
            pVec,eVec = self.conV.doc2PreEntVec(id)
            wVec = self.conV.doc2WrdVec(id)
            fVec = np.array(wVec.tolist() + pVec.tolist() + eVec.tolist())
        elif pc == 'cs':
            pVec,eVec = self.conV.cateSub2PreEntVec(id)
            wVec = self.conV.cateSub2WrdVec(id)
            fVec = np.array(wVec.tolist() + pVec.tolist() + eVec.tolist())
        elif pc == 'cp':
            fVec = self.conV.catePar2FVec(id,self.cVecDic)
        else:
            print 'no fVec generated'
            return
        return fVec

    def trainTestPidAllocation(self):
        print 'allocating training & testing data'
        for pid in self.pidList:
            if pid%3 == 0:
                self.pidTestList.append(pid)
                self.cidPredictJudgeList.append(self.sp.fetCid(pid))
            else:
                self.pidTrainList.append(pid)
        print 'training & testing data generation compete'

    def cTreeGrowth(self):

        tree = cTree.cateTree(self.cid1)

        # first level category
        tree.addChild(self.cid1,self.cid2)
        tree.addChild(self.cid1,self.cid6)
        tree.addChild(self.cid1,self.cid10)
        tree.addChild(self.cid1,self.cid14)

        # second level category
        tree.addChild(self.cid2,self.cid3)
        tree.addChild(self.cid2,self.cid4)
        tree.addChild(self.cid2,self.cid5)

        tree.addChild(self.cid6,self.cid7)
        tree.addChild(self.cid6,self.cid8)
        tree.addChild(self.cid6,self.cid9)

        tree.addChild(self.cid10,self.cid11)
        tree.addChild(self.cid10,self.cid12)
        tree.addChild(self.cid10,self.cid13)

        tree.addChild(self.cid14,self.cid15)
        tree.addChild(self.cid14,self.cid16)
        tree.addChild(self.cid14,self.cid17)

        return tree

    def cVecGen(self):
        print 'cVec Gen Started , please wait...'
        for cid in self.cidList:
            if cid in self.pageCidList:
                cVec = self.featureGen(cid,'cs')
                self.cVecDic[cid] = cVec
            else:
                cVec = self.featureGen(cid,'cp')
                self.cVecDic[cid] = cVec

    def pVecGen(self):
        print 'pVec Gen Started , please wait...'
        for pid in self.pidList:
            pVec = self.featureGen(pid,'p')
            self.pVecDic[pid] = pVec

    def cVec2fVec(self,cid1,cid2,pid):
        cVec1 = self.cVecDic[cid1]
        cVec2 = self.cVecDic[cid2]
        pVec = self.pVecDic[pid]
        trainFeatureVecX = (cVec1 - cVec2) * pVec
        return trainFeatureVecX

    def dataGen(self):
        self.trainTestPidAllocation()
        print 'start loading pVec'
        self.pVecGen()
        print 'start loading cVec'
        self.cVecGen()
        print 'training data generation started'
        start = time.clock()
        print 'generating training data , please wait...'
        for pid in self.pidTrainList:
            # can be deleted later
            parCid = self.sp.fetCid(pid)
            if parCid not in self.cidList:
                continue
            # can be deleted later
            pVec = self.pVecDic[pid]
            comb = itertools.combinations(self.cVecDic.keys(),2)
            for catePair in comb:
                cid1 = catePair[0]
                cid2 = catePair[1]
                trainFeatureVecX = self.cVec2fVec(cid1,cid2,pid)
                if self.cateTree.orderJudge(cid1,cid2,pid) == 1:
                    trainFeatureVecY = 1
                    self.trainX.append(trainFeatureVecX.tolist())
                    self.trainy.append(trainFeatureVecY)
                elif self.cateTree.orderJudge(cid1,cid2,pid) == 2:
                    trainFeatureVecY = 2
                    self.trainX.append(trainFeatureVecX.tolist())
                    self.trainy.append(trainFeatureVecY)
                else:
                    pass
        finish = time.clock()
        print 'training data generation complete'
        print 'data generation time consumed : ' + str(finish - start)

    def svmTrain(self):
        print 'svm training start , please wait...'
        start = time.clock()
        # convert the training data to csr_matrix
        sparsetrainX = sparse.csr_matrix(self.trainX)
        half = time.clock()
        print 'sparse matrix generation time consumed : ' + str(half - start)
        # convert the training data to csr_matrix
        self.clf.fit(sparsetrainX,self.trainy)
        finish = time.clock()
        print 'svm training complete'
        print 'svm training time consumed : ' + str(finish - half)

    def svmTest(self):
        print 'svm prediction start'
        for pid in self.pidTestList:
            node = self.cateTree.root
            cidPredict = self.svmTyping(node,pid)
            self.cidPredictList.append(cidPredict)
        correct = 0
        incorrect = 0
        for i in range(len(self.cidPredictJudgeList)):
            if self.cidPredictList[i] == self.cidPredictJudgeList:
                correct += 1
            else:
                incorrect += 1
        print 'svm prediction complete'
        print "precision : " + str(float(correct)/float(correct + incorrect)) +'%'

    def svmTyping(self,node,pid):
        if node.children != []:
            nNode = self.svmPredict(node,pid)
            if nNode == node:
                return nNode.cid
            else:
                return self.svmTyping(nNode,pid)
        else:
            return node.cid

    def svmPredict(self,node,pid):
        winner = -1
        if node.children == []:
            return node
        for i in range(len(node.children) - 1):
            if winner < 0:
                cid1 = node.children[i].cid
            else:
                cid1 = winner
            cid2 = node.children[i + 1].cid
            fVec = self.cVec2fVec(cid1,cid2,pid)
            res = self.clf.predict(fVec)
            if res[0] == 1:
                winner = cid1
            elif res[0] == 2:
                winner = cid2
            else:
                print 'prediction error'
                return
        fVec = self.cVec2fVec(winner,node.cid,pid)
        res = self.clf.predict(fVec)
        if res[0] == 1:
            winner = cid1
        elif res[0] == 2:
            winner = cid2
        return self.cateTree.nodeDic[winner]
































