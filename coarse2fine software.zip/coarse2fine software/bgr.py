
################### bipartite graph ranking ###################
import sqlCon
import numpy as np
import time
import datetime
import assis
from sklearn.cluster import AffinityPropagation
import random
import re
import txtPrc



class bg:
    def __init__(self,anx,cid):
        # old version
        # self.anx = anx
        # self.sp = sqlCon.sqlProcesser()
        # self.matLDic = {}
        # self.matTLDic = {}
        # self.attrListDic = {}
        # self.valueListDic = {}
        # self.attrWeightListDic = {}
        # self.valueWeightListDic = {}
        # self.clusterScoreDic = {}
        # self.buildAdMat()
        # self.cid = cid
        # old version

        self.anx = anx
        self.sp = sqlCon.sqlProcesser()
        self.cid = cid



    def reInit(self):
        self.matLDic = {}
        self.matTLDic = {}
        self.attrListDic = {}
        self.valueListDic = {}
        self.attrWeightListDic = {}
        self.valueWeightListDic = {}
        self.clusterScoreDic = {}
        self.buildAdMat()

    def buildAdMat(self):
        print 'building the adjacency matrix of the given graph, please wait...'
        start = time.clock()
        weight1 = 1.0
        weight2 = 0.5
        weight3 = 0.25
        for key in range(len(self.anx.clusterDicL1)):
            attrValueDicL1 = self.anx.clusterDicL1toValue[key]
            attrValueDicL2 = self.anx.clusterDicL2toValue[key]
            attrValueDicL3 = self.anx.clusterDicL3toValue[key]
            attrList = list(set(attrValueDicL1.keys() + attrValueDicL2.keys() + attrValueDicL3.keys()))
            valueList = self.anx.clusterValueDic[key]
            attrWeightList = np.ones(len(attrList))
            valueWeightList = []
            for value in valueList:
                valueWeightList.append(self.calImportance(value))
            valueWeightList = np.array(valueWeightList)
            adMat = np.zeros((len(attrList),len(valueList)))
            for attr in attrValueDicL1.keys():
                subValueList = attrValueDicL1[attr]
                for value in subValueList:
                    attrId = attrList.index(attr)
                    valueId = valueList.index(value)
                    adMat[attrId,valueId] += weight1
            for attr in attrValueDicL2.keys():
                subValueList = attrValueDicL2[attr]
                for value in subValueList:
                    attrId = attrList.index(attr)
                    valueId = valueList.index(value)
                    adMat[attrId,valueId] += weight2
            for attr in attrValueDicL3.keys():
                subValueList = attrValueDicL3[attr]
                for value in subValueList:
                    attrId = attrList.index(attr)
                    valueId = valueList.index(value)
                    adMat[attrId,valueId] += weight3
            self.clusterScoreDic[key] = self.clusterGrading(key)
            self.attrListDic[key] = attrList
            self.valueListDic[key] = valueList
            self.attrWeightListDic[key] = attrWeightList
            self.valueWeightListDic[key] = valueWeightList
            self.matLDic[key] = adMat
            self.matTLDic[key] = self.matTranspose(adMat)
        end = time.clock()
        print 'adjaency matrix built. time consumed : ' + str(end - start)

    # calculate the importance of an given value(entity)
    def calImportance(self,value):
        doc = self.sp.fetWikiPageContent(value)
        weight = np.log((len(doc)/10000.0) + 1)
        return weight

    # calculate the relevance of an given value(entity)
    def calRelevance(self,value):
        weight = len(self.anx.dic0Pid[value])
        return weight

    # transpose the matrix
    def matTranspose(self,mat):
        matT = np.array(zip(*mat))
        return matT

    # calculate vector difference
    def vecDifference(self,vector1,vector2):
        total = 0
        for i in range(len(vector1)):
            total += abs(vector1[i] - vector2[i])
        return total

    # Takes a vector and divides all components by the component with the max value. This means that the largest value in the vector will be 1.
    def vecNormalize(self,vector):
        max = 0
        for component in vector:
            if component > max:
                max = component
        if max == 0:
            return vector
        for i in range(len(vector)):
            vector[i] = vector[i] / float(max)
        return vector





    def clusterRankingOld(self):
        entityList = self.vecNormalize(np.ones(len(self.anx.pidList)))
        clusterList = self.vecNormalize(np.ones(len(self.anx.clusterDicL1)))
        adMat = np.zeros((len(clusterList),len(entityList)))
        for key in self.anx.clusterDicL1.keys():
            valueList = self.anx.clusterValueDic[key]
            # calculate initial value for all clusters (importance * siluatGrade)
            siluatGrade = self.anx.siluatGradeDic[key]
            importance = 0.0
            for pid in valueList:
                importance += np.log((len(self.sp.fetWikiPageContent(pid))/10000.0) + 1)
            clusterList[key] = importance * siluatGrade
            # calculate weight on edges
            relatePidDic = {}
            for i in range(len(valueList)):
                value = valueList[i]
                relatePidList = self.anx.dic0Pid[value]
                for pid in relatePidList:
                    if relatePidDic.has_key(pid):
                        relatePidDic[pid].append(value)
                    else:
                        relatePidDic[pid] = [value]
            for pid in relatePidDic.keys():
                punishIndex = np.power(np.e,len(relatePidDic[pid])-1)
                # punish the cluster
                clusterList[key] = clusterList[key] / np.power(punishIndex,(1/float(len(relatePidDic))))
                # punish edges linked to the cluster
                edgeWeight = 1.0
                edgeWeight = edgeWeight / punishIndex
                entityIndex = self.anx.pidList.index(pid)
                adMat[key,entityIndex] = edgeWeight

        # iterate to rank
        clusterListOld = self.vecNormalize(np.ones(len(self.anx.clusterDicL1)))
        entityListNew = self.vecNormalize(entityList)
        clusterListNew = self.vecNormalize(clusterList)
        adMatT = self.matTranspose(adMat)
        iterCnt = 0
        alpha = 0.5
        while self.vecDifference(clusterListNew,clusterListOld) > 0.01:
            iterCnt += 1
            clusterListOld = clusterListNew
            clusterListNew = alpha * clusterList + (1-alpha) * self.vecNormalize(np.dot(adMat,entityListNew))
            entityListNew = alpha * entityList  + (1-alpha) * self.vecNormalize(np.dot(adMatT,clusterListNew))
        clusterRankingList = []
        for i in range(len(clusterListNew)):
            clusterRankingList.append([clusterListNew[i],i])
        clusterRankingList.sort(reverse=True)
        retList = []
        for item in clusterRankingList:
            retList.append(item[1])
        return retList

    def hits(self,valueScoreDic,attrList,alpha=0.5):
        # first build attrValueMat
        attrValueMat = np.zeros((len(attrList),len(valueScoreDic)))
        valueList = valueScoreDic.keys()
        for i in range(len(attrList)):
            attr = attrList[i]
            for j in range(len(valueList)):
                value = valueList[j]
                if value in self.anx.dic10[attr]:
                    attrValueMat[i,j] = 1.0
                else:
                    pass
        self.attrValueMat = attrValueMat
        attrValueMatT = self.matTranspose(attrValueMat)
        # run hits algorithm
        iterCnt = 0
        attrOld = np.zeros(len(attrList))
        attrNew = np.ones(len(attrList))
        attr0 = attrNew[:]
        value0 = []
        for value in valueList:
            value0.append(valueScoreDic[value])
        value0 = np.array(value0)
        valueNew = value0
        while self.vecDifference(attrOld,attrNew) > 0.01:
            iterCnt += 1
            attrOld = attrNew
            attrNew = alpha * attr0 + (1-alpha) * self.vecNormalize(np.dot(attrValueMat,valueNew))
            valueNew = alpha * value0 + (1-alpha) * self.vecNormalize(np.dot(attrValueMatT,attrNew))
        # record the result
        attrScoreList = []
        for k in range(len(attrList)):
            attrScoreList.append([attrNew[k],attrList[k]])
        return attrScoreList



    # filter out cluster that are similiar to the class to be devided
    def clusterPostFilter(self,clusterId):
        sum = 0
        attrList = self.attrRanking(clusterId)[:5]
        for attr in attrList:
            cateDis = self.sp.fetWikiCateDistanceOld(attr,self.cid)
            # print cateDis
            sum += min(cateDis[0],cateDis[1])
        if sum < 5:
            return False
        else:
            return True


    # Multiplies a matrix and a vector
    def multiplyMatrixVector(self,matrix,vector):
        resultMat = {}
        for row in range(len(matrix)):
            resultMat[row] = 0
            for item in range(len(matrix[row])):
                resultMat[row] += vector[item]
        return resultMat.values()

    # grade attributes in a cluster
    def attrRanking(self,key):
        attrList = self.attrListDic[key]
        attrScore = self.hits2(key)
        rankingList = []
        resultList = []
        for i in range(len(attrScore)):
            rankingList.append([attrScore[i],i])
        rankingList.sort(reverse=True)
        for rec in rankingList:
            ind = rec[1]
            resultList.append(attrList[ind])
        return resultList

    # HITS algorithm
    def hits2(self,key):
        alpha = 0.5
        attr0 = self.attrWeightListDic[key][:]
        attrOld = np.zeros(len(attr0))
        attrN = attr0
        value0 = self.valueWeightListDic[key][:]
        valueN = value0
        matL = self.matLDic[key].copy()
        matTL = self.matTLDic[key].copy()
        iterCnt = 0
        while self.vecDifference(attrOld,attrN) > 0.01:
            iterCnt += 1
            attrOld = attrN
            attrN = alpha * attr0 + (1-alpha) * self.vecNormalize(np.dot(matL,valueN))
            valueN = alpha * value0 + (1-alpha) * self.vecNormalize(np.dot(matTL,attrN))
        # print 'iteration time : ' + str(iterCnt)
        return attrN    # valueN



    def top20top5(self):
        print 'clusterGrading...'
        writeList = []
        i = -1
        clusterList = self.clusterRanking()[:20]
        print 'writing experiment result, please wait...'
        for clusterId in clusterList:
            i += 1
            print 'top' + str(i) + ' cluster'
            writeList.append('top' + str(i) + ' cluster\n')
            print 'values : ',
            line = 'values : '
            for pid in self.anx.clusterValueDic[clusterId]:
                print self.sp.fetWikiPnameWithPid(pid) + ' ; ',
                line += self.sp.fetWikiPnameWithPid(pid) + ' ; '
            line += '\n'
            print ''
            writeList.append(line)
            j = 1
            attrList = self.attrRanking(clusterId)[:5]
            for attr in attrList:
                print ' attr' + str(j) + ' ' + str(self.sp.fetWikiCnameGivenCid(attr))
                writeList.append(' attr' + str(j) + ' ' + str(self.sp.fetWikiCnameGivenCid(attr)) + '\n')
                j += 1
        self.expRecord(writeList)
        print 'experiment result stored '



    def expRecord(self,writeList):
        now = datetime.datetime.now()
        nowStr = self.sp.fetWikiCnameGivenCid(self.cid) + str(now)[4:19].replace(':','_').replace('-','_')
        file = open(nowStr + '.txt','w')
        file.writelines(writeList)
        file.close()



####################################### start from 4.12 #######################################



    # the score of a value equals to the number of entity it relates to multiplys its importance(length)
    def valueScoring(self):
        valueScoreDic = {}
        for value in self.anx.dic0Pid.keys():
            relationScore = assis.logisticFunc(len(self.anx.dic0Pid[value]),1.3)
            importanceScore = assis.logisticFunc(len(self.sp.fetWikiPageContent(value))/3000.0,1.5)
            valueScoreDic[value] = relationScore * importanceScore
        self.valueScoreDic = valueScoreDic



    def attrScoring(self):
        attrScoreDic = {}
        attrScoreList = []

        for attr1 in self.anx.dic10.keys():
            # 1.importance & relatedness
            valueList = self.anx.dicAttrValue[attr1]
            attrScore = 0.0
            for value in valueList:
                attrScore += self.valueScoreDic[value]
            attrScoreDic[attr1] = attrScore

        for attr2 in self.anx.dic20.keys():
            valueList = self.anx.dicAttrValue[attr2]
            attrScore = 0.0
            for value in valueList:
                attrScore += self.valueScoreDic[value]
            attrScoreDic[attr2] = attrScore/np.power(np.e,1.9)

        for attr3 in self.anx.dic30.keys():
            valueList = self.anx.dicAttrValue[attr3]
            attrScore = 0.0
            for value in valueList:
                attrScore += self.valueScoreDic[value]
            attrScoreDic[attr3] = attrScore/np.power(np.e,2.8)

        for key in self.anx.dicAttrValue.keys():
            attrScoreDic[key]  = np.power(assis.logisticFunc(attrScoreDic[key]),3)
            attrScoreList.append(attrScoreDic[key])
        self.attrScoreDic = attrScoreDic
        self.attrScoreList = attrScoreList



    def attrClustering(self):
        af = AffinityPropagation(affinity='precomputed',preference=np.array(self.attrScoreList) - 12.0)
        # af = AffinityPropagation(affinity='precomputed',preference=-1.5)
        prediction = af.fit_predict(self.anx.cateDisMat)
        clusterDic = {}
        cateList = self.anx.dicAttrValue.keys()
        for i in range(len(prediction)):
            pred = prediction[i]
            cate = cateList[i]
            if clusterDic.has_key(pred):
                clusterDic[pred].append(cate)
            else:
                clusterDic[pred] = [cate]
        self.clusterDic = clusterDic
        self.clusterValueDic = {}
        for key in clusterDic.keys():
            pidList = []
            cidList = clusterDic[key]
            for cid in cidList:
                pidList += self.anx.dicAttrValue[cid]
            pidList = list(set(pidList))
            self.clusterValueDic[key] = pidList
        self.clusterCenterDic = {}
        for i in range(len(af.cluster_centers_indices_)):
            index = af.cluster_centers_indices_[i]
            self.clusterCenterDic[i] = cateList[index]
        self.siluatGradeDic = assis.siluatClusterGrade(self.anx.cateDisMat,prediction)



    def showRes(self):
        rankRes = self.clusterGrading()
        for i in range(len(rankRes)):
            clusId = rankRes[i]
            print 'rank No.' + str(i) + '   (cluster ' + str(clusId) +  ')'
            clusValues = self.clusterValueDic[clusId]
            print 'value : ',
            for value in clusValues:
                print self.sp.fetWikiPnameWithPid(value) + '; ',
            print ''
            clusItems = self.clusterDic[clusId]
            print 'attrs(first level) : ',
            for clusItem in clusItems:
                print self.sp.fetWikiCnameGivenCid(clusItem) + '; ',
            print ''
            print 'center(first level) : ',
            print self.sp.fetWikiCnameGivenCid(self.clusterCenterDic[clusId])
            self.findHighLevelCenter(clusId)
            print '\n\n\n'


    def similarityJudge(self,cid1,cid2):
        if cid1 == '' or cid2 == '':
            return 0
        dis1a,dis1b,ancester = self.sp.fetWikiCateDistanceOld(cid1,cid2)
        cname1a = assis.cNamePrc(self.sp.fetWikiCnameGivenCid(cid1))
        cname1b = assis.cNamePrc(self.sp.fetWikiCnameGivenCid(cid2))
        if dis1a * dis1b < 2 or assis.cNameCmp(cname1a,cname1b) == 1:
            return 1
        else:
            return 0

    def peopleJudge(self,valueList,on=1):
        if on == 0:
            return 0
        if len(valueList) == 0:
            print 'peopleJudge error'
            return 0
        cnt = 0
        pat = re.compile('births|deaths|Living_people')
        for i in range(10):
            randValue = valueList[random.randint(0,len(valueList)-1)]
            momCidList = self.sp.fetWikiMomCidGivenPid(randValue)
            for momCid in momCidList:
                momCidName = self.sp.fetWikiCnameGivenCid(momCid)
                if pat.search(momCidName) != None:
                    cnt += 1
                    break
        if cnt >= 6:
            return 1
        else:
            return 0





    def attrRankingMain(self):
        writeList = []
        writeList.append(str(self.cid) + ' : ' + self.sp.fetWikiCnameGivenCid(self.cid) + '\n\n')
        rankCnt = 0
        rankRes = self.clusterGrading()
        for clusId in rankRes:
            if self.peopleJudge(self.clusterValueDic[clusId],on=0) == 1:
                continue
            clusValues = self.clusterValueDic[clusId]
            attrListL1 = self.clusterDic[clusId]
            clusterCenter1 = self.clusterCenterDic[clusId]
            if self.similarityJudge(self.cid,clusterCenter1) == 1 or self.peopleJudge(self.anx.dic10[clusterCenter1],on=0) == 1:
                continue

            attrListL2 = self.clusterDicL2[clusId].keys()
            attrScoreDicL2 = self.attrScoringL2(clusId)
            if len(attrListL2) == 0:
                clusterCenter2 = ''
            else:
                try:
                    clusterCenter2 = self.attrClusteringHigh(attrListL2,attrScoreDicL2)
                except:
                    print 'error clustering : ' + str(clusId)
                    clusterCenter2 = ''
                if self.similarityJudge(self.cid,clusterCenter2) == 1 or self.peopleJudge(self.clusterDicL2toValue[clusId][clusterCenter2],on=0) == 1:
                    continue

            attrListL3 = self.clusterDicL3[clusId].keys()
            attrScoreDicL3 = self.attrScoringL3(clusId)
            if len(attrListL3) == 0:
                clusterCenter3 = ''
            else:
                try:
                    clusterCenter3 = self.attrClusteringHigh(attrListL3,attrScoreDicL3)
                except:
                    print 'error clustering : ' + str(clusId)
                    clusterCenter3 = ''
                if self.similarityJudge(self.cid,clusterCenter3) == 1 or self.peopleJudge(self.clusterDicL3toValue[clusId][clusterCenter3],on=0) == 1:
                    continue

            clusterCenter = self.centerGrading([clusterCenter1,clusterCenter2,clusterCenter3],clusId)

            rankCnt += 1
            if rankCnt > 20:
                print 'main experiment recorded'
                return writeList

            writeList.append('rank No.' + str(rankCnt) + '   (cluster ' + str(clusId) +  ')\n')
            writeList.append('  value : ')
            for value in clusValues:
                writeList.append(self.sp.fetWikiPnameWithPid(value) + '; ')
            writeList.append('\n\n')
            writeList.append('  attr(first level) : ')
            for attr1 in attrListL1:
                writeList.append(self.sp.fetWikiCnameGivenCid(attr1) + '; ')
            writeList.append('\n')
            writeList.append('  center(first level) : ')
            writeList.append(self.sp.fetWikiCnameGivenCid(clusterCenter1))
            writeList.append('\n')
            writeList.append('  attr(second level) : ')
            for attr2 in attrListL2:
                writeList.append(self.sp.fetWikiCnameGivenCid(attr2) + '; ')
            writeList.append('\n')
            writeList.append('  center(second level) : ')
            if clusterCenter2 != '':
                writeList.append(self.sp.fetWikiCnameGivenCid(clusterCenter2))
            writeList.append('\n')
            writeList.append('  attr(third level) : ')
            for attr3 in attrListL3:
                writeList.append(self.sp.fetWikiCnameGivenCid(attr3) + '; ')
            writeList.append('\n')
            writeList.append('  center(third level) : ')
            if clusterCenter3 != '':
                writeList.append(self.sp.fetWikiCnameGivenCid(clusterCenter3))
            writeList.append('\n')
            writeList.append('  final center : ')
            writeList.append(self.sp.fetWikiCnameGivenCid(clusterCenter))
            writeList.append('\n\n\n\n')

    def centerGrading(self,centerList,clusId):
        centerScoreList = []
        center1 = centerList[0]
        centerScore1 = 0
        for value in self.anx.dic10[center1]:
            centerScore1 += self.valueScoreDic[value]
        centerScoreList.append([centerScore1,center1])
        center2 = centerList[1]
        if center2 == '':
            centerScoreList.append([0,center2])
        else:
            centerScore2 = 0
            for value in self.clusterDicL2toValue[clusId][center2]:
                centerScore2 += self.valueScoreDic[value]
            centerScoreList.append([centerScore2/1.1,center2])
        center3 = centerList[2]
        if center3 == '':
            centerScoreList.append([0,center3])
        else:
            centerScore3 = 0
            for value in self.clusterDicL3toValue[clusId][center3]:
                centerScore3 += self.valueScoreDic[value]
            centerScoreList.append([centerScore3/1.2,center3])
        centerScoreList.sort(reverse=True)
        return centerScoreList[0][1]





    # grade how important an cluster is
    def clusterGrading(self):
        clusterGradeList = []
        for clusterId in self.clusterDic.keys():
            # 1.siluatGrade
            siluateGrade = self.siluatGradeDic[clusterId]
            # 2.importance * relatedness
            clusterGrade = 0
            for value in self.clusterValueDic[clusterId]:
                clusterGrade += self.valueScoreDic[value]
            clusterGradeList.append([clusterGrade * siluateGrade,clusterId])
        clusterGradeList.sort(reverse=True)
        rankRes = [item[1] for item in clusterGradeList]
        return rankRes



    def clusterRanking(self):
        entityList = self.vecNormalize(np.ones(len(self.anx.pidList)))
        clusterList = self.vecNormalize(np.ones(len(self.clusterDic)))
        adMat = np.zeros((len(clusterList),len(entityList)))
        for key in self.clusterDic.keys():
            # 1.siluatGrade
            siluatGrade = self.siluatGradeDic[key]
            # 2.importance
            valueList = self.clusterValueDic[key]
            importance = 0.0
            for pid in valueList:
                importance += self.valueScoreDic[pid]
            clusterList[key] = importance * siluatGrade
            # calculate weight on edges
            relatePidDic = {}
            for i in range(len(valueList)):
                value = valueList[i]
                relatePidList = self.anx.dic0Pid[value]
                for pid in relatePidList:
                    if relatePidDic.has_key(pid):
                        relatePidDic[pid].append(value)
                    else:
                        relatePidDic[pid] = [value]
            for pid in relatePidDic.keys():
                punishIndex = np.power(np.e,len(relatePidDic[pid])-1)
                # punish the cluster
                clusterList[key] = clusterList[key] / np.power(punishIndex,(1/float(len(relatePidDic))))
                # punish edges linked to the cluster
                edgeWeight = 1.0
                edgeWeight = edgeWeight / punishIndex
                entityIndex = self.anx.pidList.index(pid)
                adMat[key,entityIndex] = edgeWeight

        # iterate to rank
        clusterListOld = self.vecNormalize(np.ones(len(self.clusterDic)))
        entityListNew = self.vecNormalize(entityList)
        clusterListNew = self.vecNormalize(clusterList)
        adMatT = self.matTranspose(adMat)
        iterCnt = 0
        alpha = 0.5
        while self.vecDifference(clusterListNew,clusterListOld) > 0.01:
            iterCnt += 1
            clusterListOld = clusterListNew
            clusterListNew = alpha * clusterList + (1-alpha) * self.vecNormalize(np.dot(adMat,entityListNew))
            entityListNew = alpha * entityList  + (1-alpha) * self.vecNormalize(np.dot(adMatT,clusterListNew))
        clusterRankingList = []
        for i in range(len(clusterListNew)):
            clusterRankingList.append([clusterListNew[i],i])
        clusterRankingList.sort(reverse=True)
        retList = []
        for item in clusterRankingList:
            retList.append(item[1])
        return retList



####################################### start from 4.18 #######################################



    def attrScoringL1(self):
        attrScoreDic = {}
        attrScoreList = []
        for attr1 in self.anx.dic10.keys():
            ########### 1,importance & relavence ###########
            valueList = self.anx.dicAttrValue[attr1]
            attrScore = 0.0
            for value in valueList:
                attrScore += self.valueScoreDic[value]
            ########### 2.unitary ###########
            # # calculate punish index to punish attributes related to the same pid
            # punishIndex = 1
            # # find all related pid
            # relatePidDic = {}
            # # relateValueList = self.anx.dicAttrValue[attr1]
            # relateValueList = bg.anx.dicAttrValue[attr1]
            # for i in range(len(relateValueList)):
            #     value = relateValueList[i]
            #     # relatePidList = self.anx.dic0Pid[value]
            #     relatePidList = bg.anx.dic0Pid[value]
            #     for pid in relatePidList:
            #         if relatePidDic.has_key(pid):
            #             relatePidDic[pid].append(value)
            #         else:
            #             relatePidDic[pid] = [value]
            # for key in relatePidDic.keys():
            #     punishIndex += np.power(2,len(relatePidDic[key])-1)
            ########### 3.normalize ###########
            attrScore = np.power(assis.logisticFunc(attrScore),3)
            if attrScore > 0.6:
                attrScore = 1
            else:
                attrScore = 0
            attrScoreDic[attr1] = attrScore

        for key in self.anx.dic1.keys():
            attrScoreList.append(attrScoreDic[key])
        self.attrScoreDic = attrScoreDic
        self.attrScoreList = attrScoreList



    def attrScoringL2(self,key):
        attrScoreDic = {}
        attrValueDic = self.clusterDicL2toValue[key]
        for attr in attrValueDic.keys():
            ########### importance & relavence ###########
            valueList = attrValueDic[attr]
            attrScore = 0.0
            for value in valueList:
                attrScore += self.valueScoreDic[value]
            attrScore = np.power(assis.logisticFunc(attrScore),3)
            attrScoreDic[attr] = attrScore
        return attrScoreDic



    def attrScoringL3(self,key):
        attrScoreDic = {}
        attrValueDic = self.clusterDicL3toValue[key]
        for attr in attrValueDic.keys():
            ########### importance & relavence ###########
            valueList = attrValueDic[attr]
            attrScore = 0.0
            for value in valueList:
                attrScore += self.valueScoreDic[value]
            attrScore = np.power(assis.logisticFunc(attrScore),3)
            attrScoreDic[attr] = attrScore
        return attrScoreDic


    def attrGeneration(self,inputDic = {}):
        cutNum = 2
        if inputDic == {}:
            inputDic = self.clusterDic
        retDic = {}
        for key in inputDic.keys():
            subAttrList = inputDic[key]
            momAttrDic = {}
            for subAttr in subAttrList:
                momAttrList = self.sp.fetWikiMomCidGivenCid(subAttr)
                for momAttr in momAttrList:
                    if momAttrDic.has_key(momAttr):
                        momAttrDic[momAttr].add(subAttr)
                    else:
                        momAttrDic[momAttr] = set([subAttr])

            for momAttr in momAttrDic.keys():
                if len(momAttrDic[momAttr]) < cutNum:
                    momAttrDic.pop(momAttr)
            momAttrDic = self.sp.wikiCateFilter4Dic(momAttrDic)
            retDic[key] = momAttrDic
        return retDic



    def calAttrDis(self,attr1,attr2):
        momCate1 = set(self.sp.wikiCateFilter(self.sp.fetWikiMomCidGivenCid(attr1)))
        momCate2 = set(self.sp.wikiCateFilter(self.sp.fetWikiMomCidGivenCid(attr2)))
        subCate1 = set(self.sp.wikiCateFilter(self.sp.fetWikiSubcategoryIndex(attr1)))
        subCate2 = set(self.sp.wikiCateFilter(self.sp.fetWikiSubcategoryIndex(attr2)))
        ent1 = set(self.sp.fetWikiPidlistGivenCid(attr1))
        ent2 = set(self.sp.fetWikiPidlistGivenCid(attr2))
        alpha = 2
        beta = 2
        gamma = 1
        attrDis = alpha * (len(momCate1.intersection(momCate2))/(1 + 1.0*len(momCate1.union(momCate2))))\
                    + beta * (len(subCate1.intersection(subCate2))/(1 + 1.0*len(subCate1.union(subCate2))))\
                    + gamma * (len(ent1.intersection(ent2))/(1 + 1.0*len(ent1.union(ent2))))
        return attrDis



    def dicAttr2ValueHigh(self,inputDic):
        dicAttr2Value = {}
        for key in inputDic.keys():
            dicAttr2ValueGivenKey = {}
            for attr in inputDic[key].keys():
                subAttrList = inputDic[key][attr]
                valueList = []
                for subAttr in subAttrList:
                    valueList += self.anx.dic10[subAttr]
                if dicAttr2ValueGivenKey.has_key(attr):
                    dicAttr2ValueGivenKey[attr] += valueList
                else:
                    dicAttr2ValueGivenKey[attr] = valueList
                dicAttr2ValueGivenKey[attr] = list(set(dicAttr2ValueGivenKey[attr]))
            dicAttr2Value[key] = dicAttr2ValueGivenKey
        return dicAttr2Value



    def attrClusteringHigh(self,attrList,attrScoreDic):
        if len(attrList) == 1:
            return attrList[0]
        attrDisMat = np.zeros((len(attrList),len(attrList)))
        for i in range(len(attrList)):
            for j in range(len(attrList)):
                if i < j:
                    attrDisMat[i,j] = self.calAttrDis(attrList[i],attrList[j])
                elif i == j:
                    attrDisMat[i,j] = 0
                else:
                    attrDisMat[i,j] = attrDisMat[j,i]
        attrScoreList = []
        for attr in attrList:
            attrScoreList.append(attrScoreDic[attr])
        attrScoreList = np.array(attrScoreList)
        af = AffinityPropagation(affinity='precomputed',preference=attrScoreList-2.0)
        prediction = af.fit_predict(attrDisMat)
        if not prediction[0] > 0:
            attrRankList = []
            for key in attrScoreDic.keys():
                attrRankList.append([attrScoreDic[key],key])
            attrRankList.sort(reverse=True)
            return attrRankList[0][1]
        clusterDic = {}
        cateList = self.anx.dicAttrValue.keys()
        for i in range(len(prediction)):
            pred = prediction[i]
            cate = cateList[i]
            if clusterDic.has_key(pred):
                clusterDic[pred].append(cate)
            else:
                clusterDic[pred] = [cate]
        # clusterValueDic
        clusterScoreDic = {}
        clusterScoreList = []
        for clusterId in clusterDic.keys():
            pidList = []
            cidList = clusterDic[clusterId]
            for cid in cidList:
                pidList += self.anx.dicAttrValue[cid]
            pidList = list(set(pidList))
            clusterScore = 0
            for pid in pidList:
                clusterScore += self.valueScoreDic[pid]
            clusterScoreDic[clusterId] = clusterScore
            clusterScoreList.append([clusterScore,clusterId])
        clusterScoreList.sort(reverse=True)
        representation = clusterScoreList[0][1]
        return attrList[af.cluster_centers_indices_[representation]]



    def dicL3toDicL1(self):
        self.clusterDicL3toLow = {}
        for key in self.clusterDicL3.keys():
            dicL3toL1GivenKey = self.dicL3toDicL1PidGivenKey(key)
            self.clusterDicL3toLow[key] = dicL3toL1GivenKey



    def dicL3toDicL1PidGivenKey(self,key):
        dicL3 = self.clusterDicL3[key]
        dicL2 = self.clusterDicL2[key]
        dicL3toL1 = {}
        for attrL3 in dicL3.keys():
            dicL3toL1[attrL3] = []
            attrL2List = dicL3[attrL3]
            for attrL2 in attrL2List:
                attrL1List = dicL2[attrL2]
                dicL3toL1[attrL3] += attrL1List
            dicL3toL1[attrL3] = list(set(dicL3toL1[attrL3]))
        return dicL3toL1







    def buildDicAttrValue(self):
        self.valueScoring()
        self.attrScoringL1()
        self.attrClustering()

        self.clusterDicL2 = self.attrGeneration(self.clusterDic)
        self.clusterDicL2toValue = self.dicAttr2ValueHigh(self.clusterDicL2)

        self.clusterDicL3 = self.attrGeneration(self.clusterDicL2)
        self.dicL3toDicL1()
        self.clusterDicL3toValue = self.dicAttr2ValueHigh(self.clusterDicL3toLow)


    def findHighLevelCenter(self,key):
        attrListL2 = self.clusterDicL2[key].keys()
        attrScoreDicL2 = self.attrScoringL2(key)
        if len(attrListL2) == 0:
            return
        print ''
        print 'attr(second level) : ',
        for clusItem in attrListL2:
            print self.sp.fetWikiCnameGivenCid(clusItem) + '; ',
        print ''
        print 'center(second level) : ',
        print self.sp.fetWikiCnameGivenCid(self.attrClusteringHigh(attrListL2,attrScoreDicL2))

        attrListL3 = self.clusterDicL3[key].keys()
        attrScoreDicL3 = self.attrScoringL3(key)
        if len(attrListL3) == 0:
            return
        print ''
        print 'attr(third level) : ',
        for clusItem in attrListL3:
            print self.sp.fetWikiCnameGivenCid(clusItem) + '; ',
        print ''
        print 'center(third level) : ',
        print self.sp.fetWikiCnameGivenCid(self.attrClusteringHigh(attrListL3,attrScoreDicL3))


    # a baseline method : select a proper attrbute simply by calculating relatedness
    def attrRankingBase1(self):
        writeList = []
        writeList.append('a baseline method : select a proper attrbute simply by calculating relatedness\n')
        attrScoreList = []
        for attr in self.anx.dic1.keys():
            attrScoreList.append([len(self.anx.dic1Pid[attr]),attr])
        attrScoreList.sort(reverse=True)
        retList = []
        for item in attrScoreList[:70]:
            if self.similarityJudge(self.cid,item[1]) != 1 and self.peopleJudge(self.anx.dic10[item[1]]) != 1:
                retList.append(item[1])
        for i in range(min(len(retList),10)):
            writeList.append('attribute rank No.' + str(i+1) + ' : ' + self.sp.fetWikiCnameGivenCid(retList[i]) + '\n')
            # print 'attribute rank No.' + str(i+1) + ' : ' + self.sp.fetWikiCnameGivenCid(retList[i])
        writeList.append('\n\n\n')
        return writeList

    # a baseline method : select a proper attrbute simply by calculating importance
    def attrRankingBase2(self):
        writeList = []
        writeList.append('a baseline method : select a proper attrbute simply by calculating importance\n')
        attrScoreList = []
        for attr in self.anx.dic10.keys():
            valueList = self.anx.dicAttrValue[attr]
            attrScore = 0.0
            for value in valueList:
                attrScore += assis.logisticFunc(len(self.sp.fetWikiPageContent(value))/3000.0,1.5)
            attrScoreList.append([attrScore,attr])
        attrScoreList.sort(reverse=True)
        retList = []
        for item in attrScoreList[:70]:
            if self.similarityJudge(self.cid,item[1]) != 1 and self.peopleJudge(self.anx.dic10[item[1]]) != 1:
                retList.append(item[1])
        for i in range(min(len(retList),10)):
            writeList.append('attribute rank No.' + str(i+1) + ' : ' + self.sp.fetWikiCnameGivenCid(retList[i]) + '\n')
            # print 'attribute rank No.' + str(i+1) + ' : ' + self.sp.fetWikiCnameGivenCid(retList[i])
        writeList.append('\n\n\n')
        return writeList

    # a baseline method : select a proper attrbute by calculating importance & relatedness
    def attrRankingBase3(self):
        attrScoreList = []
        writeList = []
        writeList.append('a baseline method : select a proper attrbute by calculating relatedness & importance\n')
        for attr in self.anx.dic10.keys():
            ########### importance & relavence ###########
            valueList = self.anx.dicAttrValue[attr]
            attrScore = 0.0
            for value in valueList:
                attrScore += self.valueScoreDic[value]
            attrScoreList.append([attrScore,attr])
        attrScoreList.sort(reverse=True)
        retList = []
        for item in attrScoreList[:70]:
            if self.similarityJudge(self.cid,item[1]) != 1 and self.peopleJudge(self.anx.dic10[item[1]]) != 1:
                retList.append(item[1])
        for i in range(min(len(retList),10)):
            writeList.append('attribute rank No.' + str(i+1) + ' : ' + self.sp.fetWikiCnameGivenCid(retList[i]) + '\n')
            # print 'attribute rank No.' + str(i+1) + ' : ' + self.sp.fetWikiCnameGivenCid(retList[i])
        writeList.append('\n\n\n')
        return writeList



    # a baseline method, use hits to select proper attributes
    def attrRankingBase4(self):
        writeList = []
        writeList.append('a baseline method, use HITS to select proper attributes\n')
        attrScoreList = self.hits(self.valueScoreDic,self.anx.dic1.keys())
        attrScoreList.sort(reverse=True)
        retList = []
        for item in attrScoreList[:70]:
            if self.similarityJudge(self.cid,item[1]) != 1 and self.peopleJudge(self.anx.dic10[item[1]]) != 1:
                retList.append(item[1])
        for i in range(min(len(retList),10)):
            writeList.append('attribute rank No.' + str(i+1) + ' : ' + self.sp.fetWikiCnameGivenCid(retList[i]) + '\n')
            # print 'attribute rank No.' + str(i+1) + ' : ' + self.sp.fetWikiCnameGivenCid(retList[i])
        writeList.append('\n\n\n')
        return writeList



    def attrRankingBase5(self):
        attrDic = {}
        totalCnt = 0
        infoBoxCnt = 0
        for pid in self.anx.pidList:
            totalCnt += 1
            con = self.sp.fetWikiPageContent(pid)
            ipr = txtPrc.infoPrc(con)
            ipr.findAttr()
            attrList = ipr.attrList
            if attrList != []:
                infoBoxCnt += 1
            for attr in attrList:
                if attrDic.has_key(attr):
                    attrDic[attr] += 1
                else:
                    attrDic[attr] = 1
        attrCntList = []
        for attr in attrDic.keys():
            attrCntList.append([attrDic[attr],attr])
        attrCntList.sort(reverse=True)
        writeList = []
        writeList.append('a baseline method, use INFOBOX to select proper attributes\n')
        writeList.append('infoBox coverage : ' + str(infoBoxCnt/float(totalCnt)).format() + '\n')
        for i in range(min(len(attrCntList),10)):
            item = attrCntList[i]
            attr = item[1]
            writeList.append('attribute rank No.' + str(i+1) + ' : ' + attr + '\n')
        writeList.append('\n\n\n')
        return writeList



    def writeRes(self):
        wListMain = self.attrRankingMain()
        wList1 = self.attrRankingBase1()
        wList2 = self.attrRankingBase2()
        wList3 = self.attrRankingBase3()
        wList4 = self.attrRankingBase4()
        wList5 = self.attrRankingBase5()
        wList = wListMain + wList1 + wList2 + wList3 + wList4 + wList5
        self.expRecord(wList)
        print 'experiment recorded'
















